import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, 
  Clock, CheckCircle2, Star, Target, ArrowRight, Sparkles, 
  Flame, BatteryCharging, Filter, ListPlus, Wand2, Palette
} from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import { useTheme } from '../contexts/ThemeContext';
import confetti from 'canvas-confetti';
import type { Task, EnergyLog, Goal } from '../types';

interface CalendarPageProps {
  tasks: Task[];
  energyLogs: EnergyLog[];
  goals: Goal[];
  onToggleTask: (id: number) => Promise<void>;
  onEditTask: (task: Task) => void;
  onOpenNewTaskForDate: (dateStr: string) => void;
  onRescheduleTask: (taskId: number, newDateStr: string) => Promise<void>;
  onOpenTimer: () => void;
  onOpenAiBreakdown: (title: string) => void;
  onOpenGoal: (goal: Goal) => void;
}

export const CalendarPage: React.FC<CalendarPageProps> = ({
  tasks,
  energyLogs,
  goals,
  onToggleTask,
  onEditTask,
  onOpenNewTaskForDate,
  onRescheduleTask,
  onOpenTimer,
  onOpenAiBreakdown,
  onOpenGoal
}) => {
  const { playComplete, playPop } = useSound();
  const { moodColorMode, energyLevel } = useTheme();

  const isVibrant = energyLevel >= 4; // 4-5: Bright & Vibrant, 1-3: Light & Soothing Pastel

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  const [currentMonth, setCurrentMonth] = useState<Date>(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDateStr, setSelectedDateStr] = useState<string>(todayStr);
  const [showBacklogScheduler, setShowBacklogScheduler] = useState<boolean>(false);

  // Month navigation
  const handlePrevMonth = () => {
    playPop();
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    playPop();
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const handleJumpToToday = () => {
    playPop();
    setCurrentMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDateStr(todayStr);
  };

  // Calendar calculations (Monday start for RU locale)
  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();

  const monthNames = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  const daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

  // Days in month
  const firstDayIndex = (new Date(year, month, 1).getDay() + 6) % 7; // 0 for Monday
  const daysInCurrentMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarCells: Array<{
    dateStr: string;
    dayNumber: number;
    isCurrentMonth: boolean;
    isToday: boolean;
    isSelected: boolean;
  }> = [];

  // Previous month trailing days
  for (let i = firstDayIndex - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    const prevDate = new Date(year, month - 1, d);
    const dateStr = prevDate.toISOString().split('T')[0];
    calendarCells.push({
      dateStr,
      dayNumber: d,
      isCurrentMonth: false,
      isToday: dateStr === todayStr,
      isSelected: dateStr === selectedDateStr
    });
  }

  // Current month days
  for (let d = 1; d <= daysInCurrentMonth; d++) {
    const cellDate = new Date(year, month, d);
    const yyyy = cellDate.getFullYear();
    const mm = String(cellDate.getMonth() + 1).padStart(2, '0');
    const dd = String(cellDate.getDate()).padStart(2, '0');
    const dateStr = `${yyyy}-${mm}-${dd}`;
    calendarCells.push({
      dateStr,
      dayNumber: d,
      isCurrentMonth: true,
      isToday: dateStr === todayStr,
      isSelected: dateStr === selectedDateStr
    });
  }

  // Next month leading days to complete full grid
  const remainingCells = 35 - calendarCells.length;
  const targetTotal = remainingCells >= 0 ? 35 : 42;
  const toAdd = targetTotal - calendarCells.length;
  for (let d = 1; d <= toAdd; d++) {
    const nextDate = new Date(year, month + 1, d);
    const dateStr = nextDate.toISOString().split('T')[0];
    calendarCells.push({
      dateStr,
      dayNumber: d,
      isCurrentMonth: false,
      isToday: dateStr === todayStr,
      isSelected: dateStr === selectedDateStr
    });
  }

  // Helper to get tasks for a date string
  const getTasksForDate = (dateStr: string) => {
    return tasks.filter(t => {
      if (!t.due_date) {
        if (dateStr === todayStr && (t.status === 'today' || t.is_focus)) return true;
        return false;
      }
      return t.due_date.startsWith(dateStr);
    });
  };

  const getEnergyForDate = (dateStr: string) => {
    return energyLogs.find(e => e.date === dateStr);
  };

  // Selected date details
  const selectedDateTasks = getTasksForDate(selectedDateStr);
  const selectedDateFocus = selectedDateTasks.filter(t => t.is_focus);
  const selectedDateSecondary = selectedDateTasks.filter(t => !t.is_focus);
  const selectedDateEnergy = getEnergyForDate(selectedDateStr);

  const selectedDateObj = new Date(selectedDateStr + 'T00:00:00');
  const selectedFormattedDate = selectedDateObj.toLocaleDateString('ru-RU', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const totalEstimatedMinutes = selectedDateTasks.reduce((acc, t) => acc + (t.estimated_minutes || 0), 0);

  // Unscheduled backlog tasks
  const unscheduledTasks = tasks.filter(t => !t.due_date && t.status !== 'completed');

  const handleTaskCheck = async (task: Task) => {
    if (!task.is_completed) {
      playComplete();
      confetti({ particleCount: isVibrant ? 80 : 50, spread: 60, origin: { y: 0.65 } });
    } else {
      playPop();
    }
    await onToggleTask(task.id);
  };

  return (
    <div className="space-y-6 pb-20 transition-all duration-500">
      
      {/* Calendar Header Banner with Dynamic Mood Tone */}
      <section className={`rounded-3xl p-6 sm:p-7 shadow-xl text-white relative overflow-hidden transition-all duration-500 ${
        isVibrant
          ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 shadow-amber-500/15'
          : 'bg-gradient-to-r from-teal-600 via-emerald-600 to-sky-700 shadow-teal-600/15'
      }`}>
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
              <CalendarIcon className="w-3.5 h-3.5" />
              <span>Календарное планирование & Ритм</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              {isVibrant ? 'Энергичное расписание & Фокус' : 'Спокойный ритм & Забота о ресурсе'}
            </h2>
            <p className="text-xs sm:text-sm text-white/90">
              {isVibrant
                ? 'Распределяй задачи на неделю вперед в высоком темпе и достигай ключевых рубежей.'
                : 'Светлые, умиротворяющие тона: планируй бережно без перегруза и лишней спешки.'}
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <button
              onClick={() => onOpenNewTaskForDate(selectedDateStr)}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-white text-stone-900 font-bold text-xs sm:text-sm shadow-md hover:bg-stone-50 active:scale-95 transition flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Задача на {selectedDateStr === todayStr ? 'сегодня' : 'выбранную дату'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Grid + Day Agenda Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interactive Month Calendar (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 p-5 sm:p-6 shadow-xs">
            
            {/* Month Nav Bar */}
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg sm:text-xl text-stone-900 dark:text-white tracking-tight">
                  {monthNames[month]} {year}
                </h3>
                {selectedDateStr === todayStr && (
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    isVibrant
                      ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-teal-100 text-teal-900 dark:bg-teal-950 dark:text-teal-300'
                  }`}>
                    Сегодня
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleJumpToToday}
                  className="px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 text-xs font-semibold hover:bg-stone-200 transition"
                >
                  Сегодня
                </button>
                <button
                  onClick={handlePrevMonth}
                  className="p-2 rounded-xl bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 transition"
                  title="Предыдущий месяц"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextMonth}
                  className="p-2 rounded-xl bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 transition"
                  title="Следующий месяц"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Days of week header */}
            <div className="grid grid-cols-7 gap-1 text-center mb-2">
              {daysOfWeek.map((day, idx) => (
                <div
                  key={day}
                  className={`text-xs font-bold uppercase py-1 ${
                    idx >= 5 ? 'text-rose-500/80' : 'text-stone-400'
                  }`}
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Month Day Cells */}
            <div className="grid grid-cols-7 gap-1.5">
              {calendarCells.map((cell) => {
                const dayTasks = getTasksForDate(cell.dateStr);
                const hasFocus = dayTasks.some(t => t.is_focus && !t.is_completed);
                const hasCompleted = dayTasks.length > 0 && dayTasks.every(t => t.is_completed);
                const dayEnergy = getEnergyForDate(cell.dateStr);

                return (
                  <button
                    key={cell.dateStr}
                    type="button"
                    onClick={() => {
                      playPop();
                      setSelectedDateStr(cell.dateStr);
                    }}
                    className={`relative min-h-[64px] sm:min-h-[72px] p-1.5 rounded-2xl flex flex-col justify-between items-start transition-all ${
                      cell.isSelected
                        ? isVibrant
                          ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/25 ring-2 ring-amber-500 ring-offset-2 dark:ring-offset-zinc-900 font-bold z-10 scale-[1.02]'
                          : 'bg-teal-600 text-white shadow-lg shadow-teal-600/25 ring-2 ring-teal-600 ring-offset-2 dark:ring-offset-zinc-900 font-bold z-10 scale-[1.02]'
                        : cell.isToday
                        ? isVibrant
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 border-2 border-amber-300 dark:border-amber-700 font-bold'
                          : 'bg-teal-50 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 border-2 border-teal-300 dark:border-teal-700 font-bold'
                        : cell.isCurrentMonth
                        ? 'bg-stone-50/70 dark:bg-zinc-800/50 hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-800 dark:text-zinc-200 border border-stone-200/50 dark:border-zinc-800/80'
                        : 'bg-transparent text-stone-300 dark:text-zinc-600 opacity-40 hover:opacity-75'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-xs sm:text-sm font-semibold">
                        {cell.dayNumber}
                      </span>
                      {dayEnergy && (
                        <span className="text-[10px]" title={`Энергия ${dayEnergy.energy_level}/5`}>
                          {dayEnergy.energy_level >= 4 ? '⚡' : dayEnergy.energy_level === 3 ? '🌤️' : '🌿'}
                        </span>
                      )}
                    </div>

                    {/* Task Indicators */}
                    <div className="w-full flex items-center justify-between gap-1 mt-1">
                      {dayTasks.length > 0 ? (
                        <div className="flex items-center gap-1">
                          {hasFocus && (
                            <span className={`w-2 h-2 rounded-full ${cell.isSelected ? 'bg-white' : isVibrant ? 'bg-amber-500' : 'bg-teal-500'}`} />
                          )}
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded-md font-bold ${
                              cell.isSelected
                                ? 'bg-white/30 text-white'
                                : 'bg-stone-200 dark:bg-zinc-700 text-stone-700 dark:text-zinc-300'
                            }`}
                          >
                            {dayTasks.length}
                          </span>
                        </div>
                      ) : (
                        <span className="h-2" />
                      )}

                      {hasCompleted && (
                        <CheckCircle2 className={`w-3 h-3 ${cell.isSelected ? 'text-white' : 'text-emerald-500'}`} />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Legend */}
            <div className="mt-4 pt-4 border-t border-stone-100 dark:border-zinc-800 flex flex-wrap items-center justify-between text-[11px] text-stone-500 dark:text-zinc-400 gap-2">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${isVibrant ? 'bg-amber-500' : 'bg-teal-500'}`} />
                  Фокус дня
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Выполнено
                </span>
                <span className="flex items-center gap-1">
                  <span>⚡</span>
                  Чек-ин энергии
                </span>
              </div>
              <button
                onClick={() => setShowBacklogScheduler(!showBacklogScheduler)}
                className={`font-bold hover:underline flex items-center gap-1 ${
                  isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'
                }`}
              >
                <ListPlus className="w-3.5 h-3.5" />
                <span>{showBacklogScheduler ? 'Скрыть бэклог' : 'Запланировать из бэклога'}</span>
              </button>
            </div>

          </div>

          {/* Quick Backlog Scheduler Drawer */}
          {showBacklogScheduler && (
            <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200 dark:border-zinc-800 p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white flex items-center gap-1.5">
                  <Sparkles className={`w-4 h-4 ${isVibrant ? 'text-amber-500' : 'text-teal-500'}`} />
                  <span>Неразобранные задачи (назначить на {selectedDateStr}):</span>
                </h4>
                <span className="text-xs text-stone-400 font-semibold">{unscheduledTasks.length} задач</span>
              </div>

              {unscheduledTasks.length === 0 ? (
                <p className="text-xs text-stone-400 py-3 text-center">
                  Все задачи уже распределены по календарю! 🌟
                </p>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {unscheduledTasks.map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-xl bg-stone-50 dark:bg-zinc-800/70 border border-stone-200/60 dark:border-zinc-700/60 flex items-center justify-between gap-2 text-xs"
                    >
                      <span className="font-medium text-stone-800 dark:text-zinc-200 truncate flex-1">
                        {t.title}
                      </span>
                      <button
                        onClick={() => {
                          playPop();
                          onRescheduleTask(t.id, selectedDateStr);
                        }}
                        className={`px-3 py-1 rounded-lg text-white font-bold text-[11px] transition shrink-0 flex items-center gap-1 ${
                          isVibrant ? 'bg-amber-500 hover:bg-amber-600' : 'bg-teal-600 hover:bg-teal-700'
                        }`}
                      >
                        <span>На {selectedDateStr.slice(5)}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Selected Date Agenda & Scheduled Tasks (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 p-5 sm:p-6 shadow-xs space-y-5">
            
            {/* Selected Date Header */}
            <div className="flex items-start justify-between gap-3 border-b border-stone-100 dark:border-zinc-800 pb-4">
              <div>
                <span className={`text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                  isVibrant
                    ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300'
                    : 'bg-teal-100 text-teal-900 dark:bg-teal-950 dark:text-teal-300'
                }`}>
                  Повестка дня
                </span>
                <h3 className="font-extrabold text-base sm:text-lg text-stone-900 dark:text-white capitalize mt-1">
                  {selectedFormattedDate}
                </h3>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  {selectedDateTasks.length === 0
                    ? 'Свободный день — прекрасное время для отдыха или фокуса'
                    : `Запланировано ${selectedDateTasks.length} задач (~${totalEstimatedMinutes} мин)`}
                </p>
              </div>

              <button
                onClick={() => onOpenNewTaskForDate(selectedDateStr)}
                className={`p-2 rounded-xl text-white shadow-xs hover:opacity-90 transition shrink-0 ${
                  isVibrant ? 'bg-amber-500' : 'bg-teal-600'
                }`}
                title="Добавить задачу"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Energy Check-in note for selected day if logged */}
            {selectedDateEnergy && (
              <div className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
                isVibrant
                  ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200/80 dark:border-amber-900/40 text-amber-950 dark:text-amber-200'
                  : 'bg-teal-50/70 dark:bg-teal-950/30 border-teal-200/80 dark:border-teal-900/40 text-teal-950 dark:text-teal-200'
              }`}>
                <span className="text-base">⚡</span>
                <div className="space-y-0.5">
                  <span className="font-bold block">
                    Чек-ин: Энергия {selectedDateEnergy.energy_level}/5 • {selectedDateEnergy.mood}
                  </span>
                  {selectedDateEnergy.note && (
                    <p className="text-[11px] opacity-90 italic">
                      «{selectedDateEnergy.note}»
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Focus Tasks section for selected day */}
            {selectedDateFocus.length > 0 && (
              <div className="space-y-2">
                <div className={`flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${
                  isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'
                }`}>
                  <Star className={`w-3.5 h-3.5 ${isVibrant ? 'fill-amber-500 text-amber-500' : 'fill-teal-600 text-teal-600'}`} />
                  <span>Фокус дня ({selectedDateFocus.length}):</span>
                </div>

                <div className="space-y-2">
                  {selectedDateFocus.map((task) => (
                    <div
                      key={task.id}
                      className={`p-3.5 rounded-2xl border-2 transition-all ${
                        task.is_completed
                          ? 'bg-stone-50 dark:bg-zinc-800/40 border-stone-200 dark:border-zinc-800 opacity-60'
                          : isVibrant
                          ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700/60 shadow-xs'
                          : 'bg-teal-50/40 dark:bg-teal-950/20 border-teal-300 dark:border-teal-700/60 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5 flex-1 min-w-0">
                          <button
                            onClick={() => handleTaskCheck(task)}
                            className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition shrink-0 mt-0.5 ${
                              task.is_completed
                                ? 'bg-emerald-500 border-emerald-500 text-white'
                                : isVibrant ? 'border-amber-400 hover:bg-amber-100' : 'border-teal-400 hover:bg-teal-100'
                            }`}
                          >
                            {task.is_completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                          </button>
                          
                          <div className="min-w-0 flex-1">
                            <button
                              onClick={() => onEditTask(task)}
                              className={`text-xs sm:text-sm font-bold text-left block truncate ${
                                task.is_completed ? 'line-through text-stone-400' : isVibrant ? 'text-stone-900 dark:text-white hover:text-amber-600' : 'text-stone-900 dark:text-white hover:text-teal-600'
                              }`}
                            >
                              {task.title}
                            </button>
                            <span className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3" />
                              {task.estimated_minutes} мин
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => onOpenTimer()}
                          className="p-1.5 text-stone-500 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded-lg transition"
                          title="Таймер Помодоро"
                        >
                          <Flame className={`w-4 h-4 ${isVibrant ? 'text-amber-500' : 'text-teal-600'}`} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Secondary Scheduled Tasks */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-stone-400 uppercase tracking-wider">
                <span>Запланированные задачи ({selectedDateSecondary.length}):</span>
              </div>

              {selectedDateSecondary.length === 0 && selectedDateFocus.length === 0 ? (
                <div className="py-8 text-center space-y-2 bg-stone-50 dark:bg-zinc-800/40 rounded-2xl border border-stone-200/60 dark:border-zinc-800 p-4">
                  <p className="text-xs text-stone-500 dark:text-zinc-400 font-medium">
                    На этот день нет задач.
                  </p>
                  <button
                    onClick={() => onOpenNewTaskForDate(selectedDateStr)}
                    className={`text-xs font-bold hover:underline ${
                      isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'
                    }`}
                  >
                    + Запланировать задачу на эту дату
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedDateSecondary.map((task) => (
                    <div
                      key={task.id}
                      className="p-3 rounded-2xl bg-stone-50/80 dark:bg-zinc-800/60 border border-stone-200/70 dark:border-zinc-700/60 flex items-center justify-between gap-2.5 group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <button
                          onClick={() => handleTaskCheck(task)}
                          className={`w-4 h-4 rounded border flex items-center justify-center transition shrink-0 ${
                            task.is_completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-300 dark:border-zinc-600'
                          }`}
                        >
                          {task.is_completed && <CheckCircle2 className="w-3 h-3" />}
                        </button>

                        <button
                          onClick={() => onEditTask(task)}
                          className={`text-xs font-medium text-left truncate flex-1 ${
                            task.is_completed ? 'line-through text-stone-400' : isVibrant ? 'text-stone-800 dark:text-zinc-200 hover:text-amber-600' : 'text-stone-800 dark:text-zinc-200 hover:text-teal-600'
                          }`}
                        >
                          {task.title}
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[10px] text-stone-400 font-medium">
                          {task.estimated_minutes}м
                        </span>
                        
                        <button
                          onClick={() => {
                            const nextDay = new Date(selectedDateStr);
                            nextDay.setDate(nextDay.getDate() + 1);
                            const nextDateStr = nextDay.toISOString().split('T')[0];
                            playPop();
                            onRescheduleTask(task.id, nextDateStr);
                          }}
                          className="opacity-0 group-hover:opacity-100 text-[10px] px-2 py-0.5 rounded bg-stone-200 dark:bg-zinc-700 text-stone-700 dark:text-zinc-300 font-semibold transition"
                          title="Перенести на +1 день"
                        >
                          +1д
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Monthly Goals Alignment for this month */}
            {goals.length > 0 && (
              <div className="pt-2 border-t border-stone-100 dark:border-zinc-800">
                <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block mb-2">
                  Ключевые ориентиры месяца ({goals.filter(g => g.horizon === 'month').length}):
                </span>
                <div className="space-y-1.5">
                  {goals.filter(g => g.horizon === 'month').slice(0, 2).map((g) => (
                    <div
                      key={g.id}
                      onClick={() => onOpenGoal(g)}
                      className="p-2.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 cursor-pointer hover:border-emerald-300 transition flex items-center justify-between text-xs"
                    >
                      <span className="font-semibold text-emerald-900 dark:text-emerald-300 truncate">
                        🎯 {g.title}
                      </span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400 text-[11px]">
                        {g.progress}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
};
