import React, { useState } from 'react';
import { 
  Target, Plus, Calendar, CheckCircle2, TrendingUp, 
  Sparkles, Award, ArrowRight, Flame 
} from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import confetti from 'canvas-confetti';
import type { Goal, Task } from '../types';

interface GoalsPageProps {
  goals: Goal[];
  tasks: Task[];
  onOpenNewGoal: (horizon?: 'year' | 'quarter' | 'month') => void;
  onEditGoal: (goal: Goal) => void;
  onDeleteGoal: (goalId: number) => Promise<void>;
  onOpenNewTaskForGoal: (goalId: number) => void;
}

export const GoalsPage: React.FC<GoalsPageProps> = ({
  goals,
  tasks,
  onOpenNewGoal,
  onEditGoal,
  onDeleteGoal,
  onOpenNewTaskForGoal
}) => {
  const { playComplete, playPop } = useSound();
  const [horizonFilter, setHorizonFilter] = useState<'all' | 'year' | 'quarter' | 'month'>('all');

  const filteredGoals = goals.filter(g => {
    if (horizonFilter === 'all') return true;
    return g.horizon === horizonFilter;
  });

  const yearGoals = goals.filter(g => g.horizon === 'year');
  const quarterGoals = goals.filter(g => g.horizon === 'quarter');
  const monthGoals = goals.filter(g => g.horizon === 'month');

  return (
    <div className="space-y-6 pb-20">
      
      {/* Strategic Hierarchy Header */}
      <section className="rounded-3xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white p-6 sm:p-8 shadow-xl shadow-emerald-600/15 relative overflow-hidden">
        <div className="relative z-10 max-w-xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
            <Target className="w-3.5 h-3.5" />
            <span>Стратегическая ясность</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Иерархия целей: Год → Квартал → Месяц
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
            Большие годовые мечты декомпозируются в квартальные результаты и конкретные задачи текущего месяца.
          </p>
          <div className="pt-2 flex flex-wrap gap-2.5">
            <button
              onClick={() => onOpenNewGoal('month')}
              className="px-4 py-2.5 rounded-xl bg-white text-emerald-950 font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-50 active:scale-95 transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Цель на месяц</span>
            </button>
            <button
              onClick={() => onOpenNewGoal('quarter')}
              className="px-4 py-2.5 rounded-xl bg-emerald-500/40 hover:bg-emerald-500/60 text-white font-semibold text-xs sm:text-sm border border-white/20 transition"
            >
              + Квартальная цель
            </button>
            <button
              onClick={() => onOpenNewGoal('year')}
              className="px-4 py-2.5 rounded-xl bg-emerald-500/40 hover:bg-emerald-500/60 text-white font-semibold text-xs sm:text-sm border border-white/20 transition"
            >
              + Годовая цель
            </button>
          </div>
        </div>
      </section>

      {/* Horizon Switcher Tabs */}
      <div className="flex items-center justify-between gap-3 overflow-x-auto pb-1 sm:pb-0">
        <div className="flex items-center gap-1.5 bg-stone-100 dark:bg-zinc-800 p-1 rounded-2xl">
          {[
            { id: 'all', label: `Все цели (${goals.length})` },
            { id: 'month', label: `⚡ Месяц (${monthGoals.length})` },
            { id: 'quarter', label: `🎯 Квартал (${quarterGoals.length})` },
            { id: 'year', label: `🌟 Год 2026 (${yearGoals.length})` }
          ].map((h) => (
            <button
              key={h.id}
              onClick={() => {
                setHorizonFilter(h.id as 'all' | 'year' | 'quarter' | 'month');
                playPop();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                horizonFilter === h.id
                  ? 'bg-white dark:bg-zinc-900 text-stone-900 dark:text-white shadow-sm font-bold'
                  : 'text-stone-600 dark:text-zinc-400 hover:text-stone-900'
              }`}
            >
              {h.label}
            </button>
          ))}
        </div>
      </div>

      {/* Goals Grid */}
      {filteredGoals.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 p-8">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-2xl mx-auto">
            🎯
          </div>
          <h3 className="font-bold text-stone-900 dark:text-white text-base">
            Целей в этой категории пока нет
          </h3>
          <p className="text-xs text-stone-500 dark:text-zinc-400 max-w-sm mx-auto">
            Определите главные ориентиры, чтобы каждый день делать шаги к тому, что действительно важно.
          </p>
          <button
            onClick={() => onOpenNewGoal(horizonFilter === 'all' ? 'month' : horizonFilter)}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-md shadow-emerald-600/20"
          >
            + Поставить новую цель
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredGoals.map((goal) => {
            const linkedTasks = tasks.filter(t => t.goal_id === goal.id);
            const completedLinked = linkedTasks.filter(t => t.is_completed).length;
            const krCompleted = (goal.key_results || []).filter(kr => kr.is_completed).length;
            const krTotal = (goal.key_results || []).length;

            return (
              <div
                key={goal.id}
                className="rounded-3xl p-5 sm:p-6 bg-white dark:bg-zinc-900 border border-stone-200/80 dark:border-zinc-800 hover:border-emerald-400 transition shadow-xs flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                        {goal.horizon === 'year' ? '🌟 Год 2026' : goal.horizon === 'quarter' ? '🎯 Квартал Q3/Q4' : '⚡ Спринт Месяца'}
                      </span>
                      <span className="text-xs text-stone-400 font-medium">
                        {goal.category}
                      </span>
                    </div>

                    <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                      {goal.progress}%
                    </span>
                  </div>

                  <div>
                    <h3
                      onClick={() => onEditGoal(goal)}
                      className="cursor-pointer font-bold text-stone-900 dark:text-white text-base hover:text-emerald-600 transition line-clamp-2"
                    >
                      {goal.title}
                    </h3>
                    {goal.description && (
                      <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1 line-clamp-2">
                        {goal.description}
                      </p>
                    )}
                  </div>

                  {/* Progress Bar */}
                  <div>
                    <div className="w-full h-2 rounded-full bg-stone-100 dark:bg-zinc-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Key Results / OKR milestones */}
                  {krTotal > 0 && (
                    <div className="p-3 rounded-2xl bg-stone-50 dark:bg-zinc-800/60 border border-stone-100 dark:border-zinc-700/60 space-y-1.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">
                        Чекпоинты: {krCompleted} из {krTotal}
                      </span>
                      {goal.key_results.map((kr) => (
                        <div key={kr.id} className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className={`w-3.5 h-3.5 ${kr.is_completed ? 'text-emerald-500 fill-emerald-500' : 'text-stone-300'}`} />
                          <span className={`truncate ${kr.is_completed ? 'line-through text-stone-400' : 'text-stone-700 dark:text-zinc-300'}`}>
                            {kr.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Linked Tasks count badge */}
                  <div className="flex items-center justify-between text-xs text-stone-500 pt-1">
                    <span>Связанных задач: {completedLinked} из {linkedTasks.length} сделано</span>
                    {goal.target_date && (
                      <span className="text-[11px] text-stone-400">
                        Срок: {new Date(goal.target_date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-100 dark:border-zinc-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onOpenNewTaskForGoal(goal.id)}
                    className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Добавить задачу к цели</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onEditGoal(goal)}
                      className="text-xs text-stone-600 dark:text-zinc-300 font-semibold hover:underline"
                    >
                      Редактировать
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
