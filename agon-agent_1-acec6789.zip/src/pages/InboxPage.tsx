import React, { useState } from 'react';
import { 
  Inbox, Brain, Sparkles, Filter, Plus, ArrowRight, 
  Calendar, Target, Trash2, CheckCircle2, ListPlus 
} from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import { useTheme } from '../contexts/ThemeContext';
import type { Task, Goal } from '../types';

interface InboxPageProps {
  tasks: Task[];
  goals: Goal[];
  onOpenBrainDump: () => void;
  onOpenNewTask: () => void;
  onEditTask: (task: Task) => void;
  onMoveToToday: (taskId: number, isFocus: boolean) => Promise<void>;
  onDeleteTask: (taskId: number) => Promise<void>;
  onLinkToGoal: (taskId: number, goalId: number) => Promise<void>;
}

export const InboxPage: React.FC<InboxPageProps> = ({
  tasks,
  goals,
  onOpenBrainDump,
  onOpenNewTask,
  onEditTask,
  onMoveToToday,
  onDeleteTask,
  onLinkToGoal
}) => {
  const { playPop } = useSound();
  const { energyLevel } = useTheme();
  const isVibrant = energyLevel >= 4;

  const [filter, setFilter] = useState<'all' | 'unlinked' | 'urgent'>('all');
  const [search, setSearch] = useState('');

  const inboxTasks = tasks.filter(t => {
    const isInboxStatus = t.status === 'inbox' || t.status === 'backlog' || (!t.is_focus && t.status !== 'completed');
    if (!isInboxStatus) return false;

    if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === 'unlinked') return !t.goal_id;
    if (filter === 'urgent') return t.priority === 'urgent' || t.priority === 'high';
    return true;
  });

  return (
    <div className="space-y-6 pb-20 transition-all duration-500">
      
      {/* Brain Dump Hero Action Banner with Mood Styling */}
      <section className={`rounded-3xl p-6 sm:p-8 shadow-xl text-white relative overflow-hidden transition-all duration-500 ${
        isVibrant
          ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 shadow-indigo-500/15'
          : 'bg-gradient-to-r from-teal-600 via-sky-600 to-slate-700 shadow-teal-600/15'
      }`}>
        <div className="relative z-10 max-w-xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
            <Brain className="w-3.5 h-3.5" />
            <span>Очистка оперативной памяти</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Выгружай мысли, не держи всё в голове
          </h2>
          <p className="text-xs sm:text-sm text-white/90 leading-relaxed">
            Полноценный Brain Dump: напиши список задач потоком или скопируй сообщения. Система мгновенно разложит всё по полочкам.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={onOpenBrainDump}
              className="px-5 py-2.5 rounded-xl bg-white text-stone-900 font-bold text-xs sm:text-sm shadow-md hover:bg-stone-50 active:scale-95 transition flex items-center gap-2"
            >
              <ListPlus className="w-4 h-4" />
              <span>Быстрый сброс мыслей</span>
            </button>
            <button
              onClick={onOpenNewTask}
              className="px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-semibold text-xs sm:text-sm border border-white/20 transition"
            >
              + Одиночная задача
            </button>
          </div>
        </div>
      </section>

      {/* Triage & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск по неразобранным..."
            className="w-full sm:w-64 px-3.5 py-2 rounded-xl border border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-stone-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: `Все (${inboxTasks.length})` },
            { id: 'unlinked', label: 'Без целей' },
            { id: 'urgent', label: '🔥 Срочные' }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => {
                setFilter(f.id as 'all' | 'unlinked' | 'urgent');
                playPop();
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                filter === f.id
                  ? 'bg-stone-900 text-white dark:bg-white dark:text-zinc-900 shadow-xs'
                  : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400 hover:bg-stone-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Task List / Triage Queue */}
      {inboxTasks.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 p-8">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mx-auto ${
            isVibrant ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600' : 'bg-teal-50 dark:bg-teal-950/60 text-teal-600'
          }`}>
            ✨
          </div>
          <h3 className="font-bold text-stone-900 dark:text-white text-base">
            Входящие абсолютно чисты!
          </h3>
          <p className="text-xs text-stone-500 dark:text-zinc-400 max-w-sm mx-auto">
            Никакого ментального шума. Если возникнет новая идея или задача — просто добавь её в один клик.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {inboxTasks.map((task) => {
            const linkedGoal = goals.find(g => g.id === task.goal_id);

            return (
              <div
                key={task.id}
                className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-stone-200/80 dark:border-zinc-800 hover:border-indigo-300 dark:hover:border-indigo-700/60 transition shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onEditTask(task)}
                      className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white hover:underline text-left truncate"
                    >
                      {task.title}
                    </button>
                    {task.priority === 'urgent' && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                        ⚡ Срочно
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-stone-400">
                    <span>⏱️ {task.estimated_minutes} мин</span>
                    {linkedGoal ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-medium truncate max-w-[160px]">
                        🎯 {linkedGoal.title}
                      </span>
                    ) : (
                      <span className={isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'}>
                        • Не привязана к цели
                      </span>
                    )}
                  </div>
                </div>

                {/* 1-Click Triage Actions */}
                <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100 dark:border-zinc-800 justify-end">
                  
                  {/* Move into Focus Today */}
                  <button
                    onClick={() => onMoveToToday(task.id, true)}
                    className={`px-3 py-1.5 rounded-xl text-white text-xs font-semibold shadow-xs transition flex items-center gap-1 ${
                      isVibrant ? 'bg-amber-500 hover:bg-amber-600' : 'bg-teal-600 hover:bg-teal-700'
                    }`}
                    title="Сделать главным фокусом дня"
                  >
                    <span>⭐ В фокус</span>
                  </button>

                  {/* Move to Secondary Today */}
                  <button
                    onClick={() => onMoveToToday(task.id, false)}
                    className="px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-zinc-800 hover:bg-stone-200 text-stone-800 dark:text-zinc-200 text-xs font-medium transition"
                    title="Перенести в задачи на сегодня"
                  >
                    На сегодня
                  </button>

                  <button
                    onClick={() => onDeleteTask(task.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-500 rounded-lg transition"
                    title="Удалить"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
