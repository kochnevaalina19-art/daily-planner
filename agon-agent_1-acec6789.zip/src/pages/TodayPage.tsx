import React from 'react';
import { 
  Sun, Sparkles, CheckCircle2, Flame, Timer, 
  Wand2, Plus, Clock, Target, Palette, Heart, Shield
} from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import { useTheme } from '../contexts/ThemeContext';
import confetti from 'canvas-confetti';
import type { Task, EnergyLog, Goal } from '../types';

interface TodayPageProps {
  tasks: Task[];
  energyLog: EnergyLog | null;
  goals: Goal[];
  onToggleTask: (id: number) => Promise<void>;
  onEditTask: (task: Task) => void;
  onOpenNewTask: (presetFocus?: boolean) => void;
  onOpenEnergyCheckin: () => void;
  onOpenTimer: () => void;
  onOpenAiBreakdown: (title: string) => void;
  onOpenGoal: (goal: Goal) => void;
}

export const TodayPage: React.FC<TodayPageProps> = ({
  tasks,
  energyLog,
  goals,
  onToggleTask,
  onEditTask,
  onOpenNewTask,
  onOpenEnergyCheckin,
  onOpenTimer,
  onOpenAiBreakdown,
  onOpenGoal
}) => {
  const { playComplete, playPop } = useSound();
  const { moodColorMode } = useTheme();

  const energyLevel = energyLog?.energy_level || 4;
  const isVibrant = energyLevel >= 4; // Levels 4-5 = Vibrant, Levels 1-3 = Soft Soothing

  // Filter Focus Tasks (Top 1-3) vs Secondary Tasks
  const focusTasks = tasks.filter(t => t.is_focus && t.status !== 'completed');
  const completedFocusTasks = tasks.filter(t => t.is_focus && t.status === 'completed');
  const secondaryTasks = tasks.filter(t => !t.is_focus && t.status !== 'completed');
  const completedSecondaryTasks = tasks.filter(t => !t.is_focus && t.status === 'completed');

  const totalTodayTasks = focusTasks.length + completedFocusTasks.length + secondaryTasks.length + completedSecondaryTasks.length;
  const completedCount = completedFocusTasks.length + completedSecondaryTasks.length;
  const progressPercent = totalTodayTasks > 0 ? Math.round((completedCount / totalTodayTasks) * 100) : 0;

  const handleTaskCheck = async (task: Task) => {
    if (!task.is_completed) {
      playComplete();
      confetti({
        particleCount: isVibrant ? 90 : 50,
        spread: 60,
        origin: { y: 0.65 }
      });
    } else {
      playPop();
    }
    await onToggleTask(task.id);
  };

  return (
    <div className="space-y-6 pb-20 transition-all duration-500">
      
      {/* 1. Dynamic Mood-Driven Banner: Vibrant (4-5) vs Calm Soothing (1-3) */}
      <section className={`relative overflow-hidden rounded-3xl border p-5 sm:p-7 backdrop-blur-xs shadow-xs transition-all duration-500 ${
        isVibrant
          ? 'bg-gradient-to-br from-amber-500/15 via-orange-500/10 to-rose-500/15 border-amber-300 dark:border-amber-800/60 shadow-amber-500/10'
          : 'bg-gradient-to-br from-teal-500/10 via-sky-500/10 to-emerald-500/10 border-teal-200/80 dark:border-teal-900/50 shadow-teal-500/5'
      }`}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-2xl">
                {energyLevel === 5 ? '⚡' : energyLevel === 4 ? '🚀' : energyLevel === 3 ? '🌤️' : energyLevel === 2 ? '🌱' : '🛋️'}
              </span>
              <span className={`text-xs font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                isVibrant
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-teal-600 text-white shadow-xs'
              }`}>
                {isVibrant ? '🔥 Яркий заряд энергии' : '🌿 Бережный & Спокойный темп'}: {energyLevel}/5 • {energyLog?.mood || 'В ресурсе'}
              </span>

              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                isVibrant
                  ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200'
                  : 'bg-teal-100 text-teal-900 dark:bg-teal-950 dark:text-teal-200'
              }`}>
                <Palette className="w-3 h-3" />
                <span>{isVibrant ? 'Яркая палитра активна' : 'Светлая успокаивающая палитра'}</span>
              </span>
            </div>

            <h2 className="text-base sm:text-xl font-bold text-stone-900 dark:text-white leading-snug">
              {energyLog?.note ? `«${energyLog.note}»` : (
                isVibrant 
                  ? 'На пике сил: сделай самое важное дело утра в первую очередь!' 
                  : 'Спокойный день: мягкий темп, минимум задач и забота о себе.'
              )}
            </h2>

            <p className="text-xs text-stone-600 dark:text-zinc-400">
              {isVibrant
                ? '⚡ Отличное настроение! Направь энергию на Top-3 фокусные цели дня.'
                : '🌱 Спокойное состояние: светлые тона интерфейса снижают когнитивную нагрузку и защищают от стресса.'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0">
            <button
              onClick={onOpenEnergyCheckin}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-white dark:bg-zinc-800 text-stone-800 dark:text-zinc-200 text-xs font-semibold border border-stone-200 dark:border-zinc-700 hover:bg-stone-50 dark:hover:bg-zinc-700 shadow-xs transition"
            >
              Настроение & Цвета
            </button>
            <button
              onClick={onOpenTimer}
              className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl text-white text-xs font-semibold shadow-md transition flex items-center justify-center gap-1.5 ${
                isVibrant
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-amber-500/25'
                  : 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-teal-500/20'
              }`}
            >
              <Timer className="w-4 h-4" />
              <span>Фокус-таймер</span>
            </button>
          </div>

        </div>

        {/* Dynamic Daily Progress Bar */}
        <div className="mt-5 pt-4 border-t border-stone-200/40 dark:border-zinc-800/60">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-stone-700 dark:text-zinc-300">
              Дневной прогресс: {completedCount} из {totalTodayTasks} задач выполнено
            </span>
            <span className={`font-bold ${isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'}`}>
              {progressPercent}%
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-stone-200/70 dark:bg-zinc-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-700 rounded-full ${
                isVibrant
                  ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500'
                  : 'bg-gradient-to-r from-teal-400 via-emerald-400 to-sky-400'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </section>

      {/* 2. ФОКУС ДНЯ (Top 1-3 Главные Задачи — Rule of 3) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`w-6 h-6 rounded-lg text-white flex items-center justify-center text-xs font-bold ${
              isVibrant ? 'bg-amber-500' : 'bg-teal-600'
            }`}>
              ⭐
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-white tracking-tight">
              Фокус дня (Главные 1–3 задачи)
            </h3>
          </div>
          
          <button
            onClick={() => onOpenNewTask(true)}
            className={`flex items-center gap-1 text-xs font-semibold hover:underline ${
              isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Добавить в фокус</span>
          </button>
        </div>

        {focusTasks.length === 0 && completedFocusTasks.length === 0 ? (
          <div className="p-8 rounded-3xl border-2 border-dashed border-stone-200 dark:border-zinc-800 text-center space-y-3 bg-stone-50/50 dark:bg-zinc-900/30">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mx-auto ${
              isVibrant ? 'bg-amber-100 text-amber-600 dark:bg-amber-950/60' : 'bg-teal-100 text-teal-600 dark:bg-teal-950/60'
            }`}>
              🎯
            </div>
            <div className="max-w-sm mx-auto">
              <h4 className="font-bold text-stone-900 dark:text-white text-sm">
                В фокусе пока пусто
              </h4>
              <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
                Выберите 1–3 самые важные задачи дня, чтобы не распыляться и чувствовать уверенность.
              </p>
            </div>
            <button
              onClick={() => onOpenNewTask(true)}
              className={`px-5 py-2.5 rounded-xl text-white text-xs font-semibold shadow-md transition ${
                isVibrant ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20' : 'bg-teal-600 hover:bg-teal-700 shadow-teal-600/20'
              }`}
            >
              + Назначить Главную задачу
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {focusTasks.map((task, idx) => {
              const linkedGoal = goals.find(g => g.id === task.goal_id);
              const subtasksDone = (task.subtasks || []).filter(s => s.is_completed).length;
              const subtasksTotal = (task.subtasks || []).length;

              return (
                <div
                  key={task.id}
                  className={`group relative rounded-3xl p-5 bg-white dark:bg-zinc-900 border-2 transition-all flex flex-col justify-between ${
                    isVibrant
                      ? 'border-amber-300 dark:border-amber-700/60 shadow-lg shadow-amber-500/5 hover:border-amber-400'
                      : 'border-teal-300/80 dark:border-teal-800/60 shadow-md shadow-teal-500/5 hover:border-teal-400'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className={`text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full text-white tracking-wider ${
                        isVibrant ? 'bg-amber-500' : 'bg-teal-600'
                      }`}>
                        Фокус #{idx + 1}
                      </span>
                      <span className="text-xs text-stone-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {task.estimated_minutes} мин
                      </span>
                    </div>

                    <div>
                      <button
                        onClick={() => onEditTask(task)}
                        className={`text-left font-bold text-stone-900 dark:text-white text-sm sm:text-base transition leading-snug line-clamp-2 ${
                          isVibrant ? 'hover:text-amber-600' : 'hover:text-teal-600'
                        }`}
                      >
                        {task.title}
                      </button>
                      {task.description && (
                        <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1 line-clamp-2">
                          {task.description}
                        </p>
                      )}
                    </div>

                    {linkedGoal && (
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg">
                        <Target className="w-3 h-3" />
                        <span className="truncate">Цель: {linkedGoal.title}</span>
                      </div>
                    )}

                    {subtasksTotal > 0 && (
                      <div className="text-[11px] text-stone-500 dark:text-zinc-400">
                        Чек-лист: {subtasksDone} из {subtasksTotal} шагов
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-100 dark:border-zinc-800 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onOpenAiBreakdown(task.title)}
                      className="p-2 rounded-xl text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 text-xs font-semibold flex items-center gap-1 transition"
                      title="Умная декомпозиция на шаги"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                      <span className="text-[11px]">Шаги</span>
                    </button>

                    <button
                      onClick={() => handleTaskCheck(task)}
                      className={`flex-1 py-2 px-3 rounded-xl text-white text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5 active:scale-95 ${
                        isVibrant
                          ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-amber-500/20'
                          : 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-teal-500/20'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Выполнено!</span>
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Completed Focus Tasks */}
            {completedFocusTasks.map((task) => (
              <div
                key={task.id}
                className="rounded-3xl p-5 bg-stone-50 dark:bg-zinc-900/50 border border-emerald-200 dark:border-emerald-900/40 opacity-75 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    Победа дня! 🎉
                  </span>
                  <p className="line-through text-stone-400 dark:text-zinc-500 text-sm font-semibold mt-2">
                    {task.title}
                  </p>
                </div>
                <button
                  onClick={() => handleTaskCheck(task)}
                  className="mt-3 text-xs text-stone-400 hover:text-stone-600 dark:hover:text-zinc-300 text-left"
                >
                  Вернуть в работу
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 3. ВТОРОСТЕПЕННЫЕ ЗАДАЧИ & РУТИНА ДНЯ */}
      <section className="space-y-3 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 flex items-center justify-center text-xs font-bold">
              📋
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-white tracking-tight">
              Второстепенные задачи & дела ({secondaryTasks.length})
            </h3>
          </div>

          <button
            onClick={() => onOpenNewTask(false)}
            className="flex items-center gap-1 text-xs font-semibold text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white"
          >
            <Plus className="w-4 h-4" />
            <span>Добавить дело</span>
          </button>
        </div>

        {secondaryTasks.length === 0 && completedSecondaryTasks.length === 0 ? (
          <div className="p-6 rounded-2xl bg-white dark:bg-zinc-900 border border-stone-200/80 dark:border-zinc-800 text-center text-xs text-stone-400">
            Нет второстепенных задач на сегодня. Спокойный чистый день!
          </div>
        ) : (
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 divide-y divide-stone-100 dark:divide-zinc-800/80 shadow-xs overflow-hidden">
            {secondaryTasks.map((task) => {
              const linkedGoal = goals.find(g => g.id === task.goal_id);
              return (
                <div
                  key={task.id}
                  className="p-3.5 sm:p-4 flex items-center justify-between gap-3 hover:bg-stone-50/70 dark:hover:bg-zinc-800/40 transition group"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => handleTaskCheck(task)}
                      className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center text-transparent transition shrink-0 ${
                        isVibrant ? 'hover:border-amber-500 hover:text-amber-500' : 'hover:border-teal-500 hover:text-teal-500'
                      }`}
                    >
                      <CheckCircle2 className={`w-4 h-4 text-white ${isVibrant ? 'fill-amber-500' : 'fill-teal-600'}`} />
                    </button>
                    
                    <div className="min-w-0 flex-1">
                      <button
                        onClick={() => onEditTask(task)}
                        className={`text-left text-xs sm:text-sm font-medium text-stone-800 dark:text-zinc-200 truncate block w-full ${
                          isVibrant ? 'hover:text-amber-600' : 'hover:text-teal-600'
                        }`}
                      >
                        {task.title}
                      </button>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-stone-400">
                        <span>⏱️ {task.estimated_minutes}м</span>
                        {task.priority === 'urgent' && (
                          <span className="text-rose-500 font-bold">⚡ Срочно</span>
                        )}
                        {linkedGoal && (
                          <span className="text-emerald-600 dark:text-emerald-400 truncate max-w-[150px]">
                            🎯 {linkedGoal.title}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                    <button
                      onClick={() => onEditTask(task)}
                      className="px-2.5 py-1 text-[11px] rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-300 hover:bg-stone-200 transition"
                    >
                      Редактировать
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Completed secondary tasks */}
            {completedSecondaryTasks.map((task) => (
              <div
                key={task.id}
                className="p-3 sm:p-3.5 flex items-center justify-between gap-3 bg-stone-50/50 dark:bg-zinc-900/30 opacity-60"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => handleTaskCheck(task)}
                    className="w-5 h-5 rounded-lg bg-emerald-500 text-white flex items-center justify-center shrink-0"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                  <span className="line-through text-xs text-stone-400 dark:text-zinc-500 truncate">
                    {task.title}
                  </span>
                </div>
                <span className="text-[10px] text-stone-400">Готово</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 4. Strategic Goals Quick Peek */}
      {goals.length > 0 && (
        <section className="pt-2">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400">
              Связанные цели горизонта ({goals.length}):
            </h4>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {goals.slice(0, 2).map((goal) => (
              <div
                key={goal.id}
                onClick={() => onOpenGoal(goal)}
                className="cursor-pointer p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-stone-200/80 dark:border-zinc-800 hover:border-emerald-400 transition shadow-xs"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                    {goal.horizon === 'year' ? '🌟 Год' : goal.horizon === 'quarter' ? '🎯 Квартал' : '⚡ Месяц'}
                  </span>
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                    {goal.progress}%
                  </span>
                </div>
                <h5 className="font-bold text-xs sm:text-sm text-stone-900 dark:text-white truncate">
                  {goal.title}
                </h5>
                <div className="w-full h-1.5 rounded-full bg-stone-100 dark:bg-zinc-800 mt-2.5 overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full"
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

    </div>
  );
};
