import React, { useState } from 'react';
import { 
  StickyNote, Plus, Search, Pin, CheckSquare, 
  Trash2, ArrowRight, Tag, Sparkles 
} from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import type { Note } from '../types';

interface NotesPageProps {
  notes: Note[];
  onOpenNewNote: () => void;
  onEditNote: (note: Note) => void;
  onDeleteNote: (noteId: number) => Promise<void>;
  onConvertToTask: (taskTitle: string) => void;
}

export const NotesPage: React.FC<NotesPageProps> = ({
  notes,
  onOpenNewNote,
  onEditNote,
  onDeleteNote,
  onConvertToTask
}) => {
  const { playPop } = useSound();
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  // Collect unique tags
  const allTags = Array.from(new Set(notes.flatMap(n => n.tags || [])));

  const filteredNotes = notes.filter(n => {
    if (search && !n.title.toLowerCase().includes(search.toLowerCase()) && !n.content.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (selectedTag !== 'all' && !(n.tags || []).includes(selectedTag)) {
      return false;
    }
    return true;
  });

  const getCardColorClass = (color: string) => {
    switch (color) {
      case 'rose':
        return 'bg-rose-50/70 dark:bg-rose-950/20 border-rose-200/80 dark:border-rose-900/40';
      case 'sky':
        return 'bg-sky-50/70 dark:bg-sky-950/20 border-sky-200/80 dark:border-sky-900/40';
      case 'emerald':
        return 'bg-emerald-50/70 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-900/40';
      case 'purple':
        return 'bg-purple-50/70 dark:bg-purple-950/20 border-purple-200/80 dark:border-purple-900/40';
      default:
        return 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-900/40';
    }
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-stone-900 dark:text-white tracking-tight flex items-center gap-2">
            <StickyNote className="w-5 h-5 text-amber-500" />
            <span>Заметки, Смыслы & Инсайты</span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-zinc-400">
            Сохраняй мысли, списки и превращай пункты в задачи одним кликом
          </p>
        </div>

        <button
          onClick={onOpenNewNote}
          className="px-4 py-2.5 rounded-xl bg-stone-900 dark:bg-white text-white dark:text-zinc-900 text-xs font-bold shadow-md hover:opacity-95 active:scale-95 transition flex items-center justify-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Новая заметка</span>
        </button>
      </div>

      {/* Search & Tag Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск по заметкам и мыслям..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-stone-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        {allTags.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setSelectedTag('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedTag === 'all'
                  ? 'bg-stone-900 text-white dark:bg-white dark:text-zinc-900 shadow-xs'
                  : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
              }`}
            >
              Все теги
            </button>
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  setSelectedTag(tag);
                  playPop();
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition ${
                  selectedTag === tag
                    ? 'bg-amber-500 text-white shadow-xs font-bold'
                    : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-zinc-900 rounded-3xl border border-stone-200/80 dark:border-zinc-800 p-8">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center text-2xl mx-auto">
            📝
          </div>
          <h3 className="font-bold text-stone-900 dark:text-white text-base">
            Заметок пока нет
          </h3>
          <p className="text-xs text-stone-500 dark:text-zinc-400 max-w-sm mx-auto">
            Запишите ценную мысль, список покупок или структуру встречи прямо сейчас.
          </p>
          <button
            onClick={onOpenNewNote}
            className="px-5 py-2.5 rounded-xl bg-amber-500 text-white text-xs font-semibold shadow-md shadow-amber-500/20"
          >
            + Создать первую заметку
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              className={`rounded-3xl p-5 border shadow-sm flex flex-col justify-between transition-all hover:shadow-md ${getCardColorClass(note.color)}`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <h3
                    onClick={() => onEditNote(note)}
                    className="cursor-pointer font-bold text-stone-900 dark:text-white text-sm sm:text-base hover:underline line-clamp-1"
                  >
                    {note.title}
                  </h3>
                  {note.is_pinned && (
                    <Pin className="w-4 h-4 text-amber-600 fill-amber-500 shrink-0" />
                  )}
                </div>

                {note.content && (
                  <p
                    onClick={() => onEditNote(note)}
                    className="cursor-pointer text-xs text-stone-700 dark:text-zinc-300 whitespace-pre-wrap line-clamp-4 leading-relaxed"
                  >
                    {note.content}
                  </p>
                )}

                {/* Checklists inside note */}
                {(note.checklist || []).length > 0 && (
                  <div className="space-y-1 pt-1">
                    {note.checklist.slice(0, 3).map((item) => (
                      <div key={item.id} className="flex items-center justify-between text-xs gap-1.5">
                        <span className={`truncate ${item.checked ? 'line-through text-stone-400' : 'text-stone-800 dark:text-zinc-200'}`}>
                          • {item.text}
                        </span>
                        <button
                          onClick={() => onConvertToTask(item.text)}
                          className="text-[10px] text-amber-700 dark:text-amber-400 font-bold hover:underline shrink-0"
                          title="Превратить пункт в задачу"
                        >
                          → в задачу
                        </button>
                      </div>
                    ))}
                    {note.checklist.length > 3 && (
                      <span className="text-[10px] text-stone-400 block">
                        + ещё {note.checklist.length - 3} пунктов...
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-stone-200/50 dark:border-zinc-800/60 flex items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1">
                  {(note.tags || []).map((tag) => (
                    <span key={tag} className="text-[10px] font-semibold text-stone-500 dark:text-zinc-400">
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onEditNote(note)}
                    className="text-xs text-stone-600 dark:text-zinc-300 font-semibold hover:underline"
                  >
                    Открыть
                  </button>
                  <button
                    onClick={() => onDeleteNote(note.id)}
                    className="p-1 text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
