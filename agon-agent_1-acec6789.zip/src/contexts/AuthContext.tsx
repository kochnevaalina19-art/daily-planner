import React, { createContext, useContext, useState, useEffect } from 'react';
import supabase from '../lib/supabase';
import type { User, Session } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isDemoUser: boolean;
  loginAsDemo: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  loading: true,
  isDemoUser: false,
  loginAsDemo: async () => {},
  signOut: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDemoUser, setIsDemoUser] = useState(false);

  useEffect(() => {
    // Check local storage for demo flag
    const savedDemo = localStorage.getItem('focus_energy_demo_mode');
    if (savedDemo === 'true') {
      setIsDemoUser(true);
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const loginAsDemo = async () => {
    localStorage.setItem('focus_energy_demo_mode', 'true');
    setIsDemoUser(true);
    // Try sign in with demo credentials if exists, otherwise mock user state
    try {
      await supabase.auth.signInWithPassword({
        email: 'demo@focusflow.app',
        password: 'password123'
      });
    } catch {
      // Demo fallback local state is already set
    }
  };

  const signOut = async () => {
    localStorage.removeItem('focus_energy_demo_mode');
    setIsDemoUser(false);
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, isDemoUser, loginAsDemo, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
