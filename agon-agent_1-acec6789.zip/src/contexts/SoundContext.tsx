import React, { createContext, useContext, useState, useEffect } from 'react';
import { soundFX } from '../lib/soundFX';

export type AmbientSound = 'off' | 'rain' | 'whitenoise' | 'zen' | 'cafe';

interface SoundContextType {
  isMuted: boolean;
  toggleMute: () => void;
  ambientSound: AmbientSound;
  setAmbientSound: (type: AmbientSound) => void;
  playComplete: () => void;
  playPop: () => void;
  playBell: () => void;
}

const SoundContext = createContext<SoundContextType>({
  isMuted: false,
  toggleMute: () => {},
  ambientSound: 'off',
  setAmbientSound: () => {},
  playComplete: () => {},
  playPop: () => {},
  playBell: () => {},
});

export const SoundProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('focus_sound_muted') === 'true';
  });
  const [ambientSound, setAmbientSoundState] = useState<AmbientSound>('off');

  useEffect(() => {
    soundFX.setMuted(isMuted);
    localStorage.setItem('focus_sound_muted', isMuted ? 'true' : 'false');
  }, [isMuted]);

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const setAmbientSound = (type: AmbientSound) => {
    setAmbientSoundState(type);
    if (type === 'off') {
      soundFX.stopAmbient();
    } else {
      soundFX.startAmbient(type);
    }
  };

  const playComplete = () => soundFX.playCompleteSound();
  const playPop = () => soundFX.playPopSound();
  const playBell = () => soundFX.playBellSound();

  return (
    <SoundContext.Provider
      value={{
        isMuted,
        toggleMute,
        ambientSound,
        setAmbientSound,
        playComplete,
        playPop,
        playBell
      }}
    >
      {children}
    </SoundContext.Provider>
  );
};

export const useSound = () => useContext(SoundContext);
