import React, { createContext, useContext, useState, useEffect } from 'react';

export type AppTheme = 'warm' | 'dark' | 'sage';
export type MoodColorMode = 'vibrant' | 'calm';

interface ThemeContextType {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  energyLevel: number;
  setEnergyLevel: (level: number) => void;
  moodColorMode: MoodColorMode;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'warm',
  setTheme: () => {},
  energyLevel: 4,
  setEnergyLevel: () => {},
  moodColorMode: 'vibrant',
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<AppTheme>(() => {
    const saved = localStorage.getItem('focus_theme') as AppTheme;
    return saved || 'warm';
  });

  const [energyLevel, setEnergyLevelState] = useState<number>(() => {
    const saved = localStorage.getItem('focus_energy_level');
    return saved ? Number(saved) : 4;
  });

  const moodColorMode: MoodColorMode = energyLevel >= 4 ? 'vibrant' : 'calm';

  useEffect(() => {
    localStorage.setItem('focus_theme', theme);
    const root = document.documentElement;
    root.classList.remove('theme-warm', 'theme-dark', 'theme-sage');
    root.classList.add(`theme-${theme}`);
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('focus_energy_level', String(energyLevel));
    const root = document.documentElement;
    root.classList.remove('mood-vibrant', 'mood-calm');
    root.classList.add(energyLevel >= 4 ? 'mood-vibrant' : 'mood-calm');
  }, [energyLevel]);

  const setEnergyLevel = (level: number) => {
    setEnergyLevelState(level);
  };

  return (
    <ThemeContext.Provider
      value={{
        theme,
        setTheme: setThemeState,
        energyLevel,
        setEnergyLevel,
        moodColorMode
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
