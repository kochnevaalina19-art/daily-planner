import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { TodayPage } from './pages/TodayPage';
import { CalendarPage } from './pages/CalendarPage';
import { InboxPage } from './pages/InboxPage';
import { NotesPage } from './pages/NotesPage';
import { GoalsPage } from './pages/GoalsPage';
import { EnergyCheckinModal } from './components/EnergyCheckinModal';
import { BrainDumpModal } from './components/BrainDumpModal';
import { TaskModal } from './components/TaskModal';
import { GoalModal } from './components/GoalModal';
import { NoteModal } from './components/NoteModal';
import { FlowTimerModal } from './components/FlowTimerModal';
import { AiBreakdownModal } from './components/AiBreakdownModal';
import { AuthModal } from './components/AuthModal';
import { SoundProvider } from './contexts/SoundContext';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { handleGoogleRedirect } from './lib/googleAuth';
import type { Task, EnergyLog, Goal, Note, ActiveTab } from './types';

// Handle Google redirect on startup
handleGoogleRedirect();

function MainApp() {
  const { user, isDemoUser } = useAuth();
  const { setEnergyLevel: setGlobalEnergyLevel } = useTheme();
  const userId = user?.id || (isDemoUser ? 'demo-user' : 'demo-user');

  const [activeTab, setActiveTab] = useState<ActiveTab>('today');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [energyLogs, setEnergyLogs] = useState<EnergyLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals state
  const [isEnergyOpen, setIsEnergyOpen] = useState(false);
  const [isBrainDumpOpen, setIsBrainDumpOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [defaultGoalHorizon, setDefaultGoalHorizon] = useState<'year' | 'quarter' | 'month'>('month');
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isTimerOpen, setIsTimerOpen] = useState(false);
  const [isAiBreakdownOpen, setIsAiBreakdownOpen] = useState(false);
  const [aiBreakdownTaskTitle, setAiBreakdownTaskTitle] = useState('');
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Fetch all core data from API routes
  const fetchAllData = async () => {
    try {
      setLoading(true);
      const [tasksRes, goalsRes, notesRes, energyRes] = await Promise.all([
        fetch(`/api/tasks?user_id=${userId}`),
        fetch(`/api/goals?user_id=${userId}`),
        fetch(`/api/notes?user_id=${userId}`),
        fetch(`/api/energy?user_id=${userId}`)
      ]);

      const [tasksData, goalsData, notesData, energyData] = await Promise.all([
        tasksRes.ok ? tasksRes.json() : [],
        goalsRes.ok ? goalsRes.json() : [],
        notesRes.ok ? notesRes.json() : [],
        energyRes.ok ? energyRes.json() : []
      ]);

      setTasks(tasksData || []);
      setGoals(goalsData || []);
      setNotes(notesData || []);
      setEnergyLogs(energyData || []);

      if (energyData && energyData.length > 0) {
        setGlobalEnergyLevel(energyData[0].energy_level);
      }
    } catch (err) {
      console.error('Failed to fetch data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [userId]);

  const currentEnergyLog = energyLogs.length > 0 ? energyLogs[0] : null;

  // Task Mutations
  const handleSaveTask = async (taskData: Partial<Task>) => {
    const isEditing = Boolean(taskData.id);
    const method = isEditing ? 'PUT' : 'POST';
    const res = await fetch('/api/tasks', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...taskData, user_id: userId })
    });
    if (res.ok) fetchAllData();
  };

  const handleToggleTask = async (taskId: number) => {
    const target = tasks.find(t => t.id === taskId);
    if (!target) return;
    const nextCompleted = !target.is_completed;
    const res = await fetch('/api/tasks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: taskId,
        is_completed: nextCompleted,
        status: nextCompleted ? 'completed' : (target.is_focus ? 'today' : 'inbox')
      })
    });
    if (res.ok) fetchAllData();
  };

  const handleMoveToToday = async (taskId: number, isFocus: boolean) => {
    const res = await fetch('/api/tasks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: taskId,
        is_focus: isFocus,
        status: 'today'
      })
    });
    if (res.ok) fetchAllData();
  };

  const handleDeleteTask = async (taskId: number) => {
    const res = await fetch('/api/tasks', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: taskId })
    });
    if (res.ok) fetchAllData();
  };

  const handleLinkToGoal = async (taskId: number, goalId: number) => {
    const res = await fetch('/api/tasks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: taskId, goal_id: goalId })
    });
    if (res.ok) fetchAllData();
  };

  const handleRescheduleTask = async (taskId: number, newDateStr: string) => {
    const res = await fetch('/api/tasks', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: taskId, due_date: newDateStr })
    });
    if (res.ok) fetchAllData();
  };

  const handleImportBrainDump = async (importedTasks: Array<{ title: string; priority: 'low' | 'medium' | 'high' | 'urgent'; is_focus: boolean }>) => {
    for (const t of importedTasks) {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          title: t.title,
          priority: t.priority,
          is_focus: t.is_focus,
          status: t.is_focus ? 'today' : 'inbox'
        })
      });
    }
    fetchAllData();
  };

  const handleImportAiSteps = async (steps: Array<{ title: string; estimated_minutes: number }>) => {
    for (const s of steps) {
      await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          title: s.title,
          estimated_minutes: s.estimated_minutes,
          priority: 'medium',
          status: 'today'
        })
      });
    }
    fetchAllData();
  };

  // Energy Log Mutation
  const handleSaveEnergy = async (logData: Partial<EnergyLog>) => {
    const res = await fetch('/api/energy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...logData, user_id: userId })
    });
    if (res.ok) fetchAllData();
  };

  // Goal Mutations
  const handleSaveGoal = async (goalData: Partial<Goal>) => {
    const isEditing = Boolean(goalData.id);
    const method = isEditing ? 'PUT' : 'POST';
    const res = await fetch('/api/goals', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...goalData, user_id: userId })
    });
    if (res.ok) fetchAllData();
  };

  const handleDeleteGoal = async (goalId: number) => {
    const res = await fetch('/api/goals', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: goalId })
    });
    if (res.ok) fetchAllData();
  };

  // Note Mutations
  const handleSaveNote = async (noteData: Partial<Note>) => {
    const isEditing = Boolean(noteData.id);
    const method = isEditing ? 'PUT' : 'POST';
    const res = await fetch('/api/notes', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...noteData, user_id: userId })
    });
    if (res.ok) fetchAllData();
  };

  const handleDeleteNote = async (noteId: number) => {
    const res = await fetch('/api/notes', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: noteId })
    });
    if (res.ok) fetchAllData();
  };

  const handleConvertNoteItemToTask = async (taskTitle: string) => {
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: userId,
        title: taskTitle,
        status: 'today',
        priority: 'medium'
      })
    });
    fetchAllData();
    setActiveTab('today');
  };

  // Counts for badges
  const inboxCount = tasks.filter(t => (t.status === 'inbox' || t.status === 'backlog') && !t.is_completed).length;
  const todayCount = tasks.filter(t => (t.status === 'today' || t.is_focus) && !t.is_completed).length;
  const scheduledCount = tasks.filter(t => t.due_date && !t.is_completed).length;
  const completedTodayCount = tasks.filter(t => t.is_completed).length;

  return (
    <div className="min-h-screen bg-[#FAF9F6] dark:bg-zinc-950 text-stone-900 dark:text-zinc-100 font-sans transition-colors selection:bg-amber-500/20">
      
      {/* Top Header */}
      <Header
        currentEnergyLog={currentEnergyLog}
        onOpenEnergyCheckin={() => setIsEnergyOpen(true)}
        onOpenBrainDump={() => setIsBrainDumpOpen(true)}
        onOpenTimer={() => setIsTimerOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenNewTask={() => {
          setSelectedTask(null);
          setIsTaskModalOpen(true);
        }}
        tasksCompletedTodayCount={completedTodayCount}
      />

      {/* Navigation Switcher */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        inboxCount={inboxCount}
        todayCount={todayCount}
        scheduledCount={scheduledCount}
        notesCount={notes.length}
        goalsCount={goals.length}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-12">
        {loading && tasks.length === 0 ? (
          <div className="py-24 text-center space-y-4">
            <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-stone-500 dark:text-zinc-400 font-medium tracking-wide">
              Загружаем ваше пространство ясности и фокуса...
            </p>
          </div>
        ) : (
          <>
            {activeTab === 'today' && (
              <TodayPage
                tasks={tasks}
                energyLog={currentEnergyLog}
                goals={goals}
                onToggleTask={handleToggleTask}
                onEditTask={(task) => {
                  setSelectedTask(task);
                  setIsTaskModalOpen(true);
                }}
                onOpenNewTask={(presetFocus) => {
                  setSelectedTask(presetFocus ? ({ is_focus: true } as Task) : null);
                  setIsTaskModalOpen(true);
                }}
                onOpenEnergyCheckin={() => setIsEnergyOpen(true)}
                onOpenTimer={() => setIsTimerOpen(true)}
                onOpenAiBreakdown={(title) => {
                  setAiBreakdownTaskTitle(title);
                  setIsAiBreakdownOpen(true);
                }}
                onOpenGoal={(goal) => {
                  setSelectedGoal(goal);
                  setIsGoalModalOpen(true);
                }}
              />
            )}

            {activeTab === 'calendar' && (
              <CalendarPage
                tasks={tasks}
                energyLogs={energyLogs}
                goals={goals}
                onToggleTask={handleToggleTask}
                onEditTask={(task) => {
                  setSelectedTask(task);
                  setIsTaskModalOpen(true);
                }}
                onOpenNewTaskForDate={(dateStr) => {
                  setSelectedTask({ due_date: dateStr, is_focus: false } as Task);
                  setIsTaskModalOpen(true);
                }}
                onRescheduleTask={handleRescheduleTask}
                onOpenTimer={() => setIsTimerOpen(true)}
                onOpenAiBreakdown={(title) => {
                  setAiBreakdownTaskTitle(title);
                  setIsAiBreakdownOpen(true);
                }}
                onOpenGoal={(goal) => {
                  setSelectedGoal(goal);
                  setIsGoalModalOpen(true);
                }}
              />
            )}

            {activeTab === 'inbox' && (
              <InboxPage
                tasks={tasks}
                goals={goals}
                onOpenBrainDump={() => setIsBrainDumpOpen(true)}
                onOpenNewTask={() => {
                  setSelectedTask(null);
                  setIsTaskModalOpen(true);
                }}
                onEditTask={(task) => {
                  setSelectedTask(task);
                  setIsTaskModalOpen(true);
                }}
                onMoveToToday={handleMoveToToday}
                onDeleteTask={handleDeleteTask}
                onLinkToGoal={handleLinkToGoal}
              />
            )}

            {activeTab === 'notes' && (
              <NotesPage
                notes={notes}
                onOpenNewNote={() => {
                  setSelectedNote(null);
                  setIsNoteModalOpen(true);
                }}
                onEditNote={(note) => {
                  setSelectedNote(note);
                  setIsNoteModalOpen(true);
                }}
                onDeleteNote={handleDeleteNote}
                onConvertToTask={handleConvertNoteItemToTask}
              />
            )}

            {activeTab === 'goals' && (
              <GoalsPage
                goals={goals}
                tasks={tasks}
                onOpenNewGoal={(horizon) => {
                  setSelectedGoal(null);
                  setDefaultGoalHorizon(horizon || 'month');
                  setIsGoalModalOpen(true);
                }}
                onEditGoal={(goal) => {
                  setSelectedGoal(goal);
                  setIsGoalModalOpen(true);
                }}
                onDeleteGoal={handleDeleteGoal}
                onOpenNewTaskForGoal={(goalId) => {
                  setSelectedTask({ goal_id: goalId, is_focus: false } as Task);
                  setIsTaskModalOpen(true);
                }}
              />
            )}
          </>
        )}
      </main>

      {/* Global Modals */}
      <EnergyCheckinModal
        isOpen={isEnergyOpen}
        onClose={() => setIsEnergyOpen(false)}
        currentLog={currentEnergyLog}
        onSave={handleSaveEnergy}
      />

      <BrainDumpModal
        isOpen={isBrainDumpOpen}
        onClose={() => setIsBrainDumpOpen(false)}
        onImportTasks={handleImportBrainDump}
      />

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        task={selectedTask}
        goals={goals}
        onSave={handleSaveTask}
        onOpenAiBreakdown={(title) => {
          setAiBreakdownTaskTitle(title);
          setIsAiBreakdownOpen(true);
        }}
      />

      <GoalModal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        goal={selectedGoal}
        defaultHorizon={defaultGoalHorizon}
        onSave={handleSaveGoal}
      />

      <NoteModal
        isOpen={isNoteModalOpen}
        onClose={() => setIsNoteModalOpen(false)}
        note={selectedNote}
        onSave={handleSaveNote}
        onConvertToTask={handleConvertNoteItemToTask}
      />

      <FlowTimerModal
        isOpen={isTimerOpen}
        onClose={() => setIsTimerOpen(false)}
        tasks={tasks}
        onTaskCompleted={handleToggleTask}
      />

      <AiBreakdownModal
        isOpen={isAiBreakdownOpen}
        onClose={() => setIsAiBreakdownOpen(false)}
        initialTaskTitle={aiBreakdownTaskTitle}
        onImportStepsAsTasks={handleImportAiSteps}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <SoundProvider>
          <MainApp />
        </SoundProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}
