export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'inbox' | 'today' | 'scheduled' | 'completed' | 'backlog';
export type TaskHorizon = 'day' | 'week' | 'month' | 'quarter' | 'year';

export interface Subtask {
  id: string;
  title: string;
  is_completed: boolean;
}

export interface Task {
  id: number;
  user_id: string;
  title: string;
  description?: string;
  is_focus: boolean;
  is_completed: boolean;
  status: TaskStatus;
  priority: Priority;
  horizon: TaskHorizon;
  goal_id?: number | null;
  due_date?: string | null;
  estimated_minutes: number;
  actual_minutes: number;
  subtasks: Subtask[];
  created_at: string;
}

export interface EnergyLog {
  id: number;
  user_id: string;
  date: string;
  energy_level: number; // 1 to 5
  mood: string;
  note: string;
  focus_state: string;
  created_at: string;
}

export interface KeyResult {
  id: string;
  title: string;
  current: number;
  target: number;
  unit: string;
  is_completed: boolean;
}

export interface Goal {
  id: number;
  user_id: string;
  title: string;
  description?: string;
  horizon: 'year' | 'quarter' | 'month';
  category: string;
  target_date?: string | null;
  progress: number; // 0 - 100
  status: 'in_progress' | 'completed' | 'paused';
  key_results: KeyResult[];
  color: string;
  created_at: string;
}

export interface NoteChecklistItem {
  id: string;
  text: string;
  checked: boolean;
}

export interface Note {
  id: number;
  user_id: string;
  title: string;
  content: string;
  tags: string[];
  is_pinned: boolean;
  color: string;
  checklist: NoteChecklistItem[];
  created_at: string;
}

export type ActiveTab = 'today' | 'calendar' | 'inbox' | 'notes' | 'goals';
