import React, { useState } from 'react';
import { X, Sparkles, Brain, ArrowRight, ListPlus } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';

interface BrainDumpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportTasks: (tasks: Array<{ title: string; priority: 'low' | 'medium' | 'high' | 'urgent'; is_focus: boolean }>) => Promise<void>;
}

export const BrainDumpModal: React.FC<BrainDumpModalProps> = ({
  isOpen,
  onClose,
  onImportTasks
}) => {
  const { playComplete, playPop } = useSound();
  const [rawText, setRawText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleProcessAndSave = async () => {
    if (!rawText.trim()) return;
    setIsProcessing(true);

    // Parse lines, strip bullets, numbers, hyphens
    const lines = rawText
      .split('\n')
      .map(l => l.replace(/^[-*•\d.)\]\s]+/, '').trim())
      .filter(l => l.length > 1);

    if (lines.length === 0) {
      setIsProcessing(false);
      return;
    }

    const parsedTasks = lines.map((title, index) => {
      const lower = title.toLowerCase();
      let priority: 'low' | 'medium' | 'high' | 'urgent' = 'medium';
      if (lower.includes('срочно') || lower.includes('важно') || lower.includes('asap') || lower.includes('горят')) {
        priority = 'urgent';
      } else if (lower.includes('главн') || lower.includes('ключев')) {
        priority = 'high';
      }

      return {
        title,
        priority,
        is_focus: index === 0 // First line can automatically suggest focus
      };
    });

    playComplete();
    await onImportTasks(parsedTasks);
    setIsProcessing(false);
    setRawText('');
    onClose();
  };

  const samplePrompts = [
    'Позвонить врачу и записаться',
    'Отправить коммерческое предложение клиенту',
    'Заказать витамины и корм',
    'Проверить баланс бюджета на неделю'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-2xl shadow-inner">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight">
              Сброс мыслей (Brain Dump)
            </h2>
            <p className="text-xs text-stone-500 dark:text-zinc-400">
              Выгрузи всё, что крутится в голове. Каждая строка станет отдельной задачей!
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="relative">
            <textarea
              rows={8}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Вставляй список или пиши потоком:&#10;— Отправить отчет руководителю&#10;— Купить кофе и фрукты&#10;— Записаться на массаж&#10;— Проверить макеты дизайна..."
              className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800/70 text-stone-900 dark:text-white text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono leading-relaxed"
            />
          </div>

          {/* Quick chip prompts */}
          <div>
            <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block mb-1.5">
              Быстрые примеры (кликни, чтобы добавить):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {samplePrompts.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => {
                    playPop();
                    setRawText(prev => prev ? `${prev}\n${prompt}` : prompt);
                  }}
                  className="text-xs px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 transition"
                >
                  + {prompt}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 flex items-start gap-2.5 text-xs text-indigo-900 dark:text-indigo-200">
            <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
            <span>
              Умный парсер автоматически разобьет текст по строкам, определит важность и поместит задачи во <strong>Входящие</strong>, чтобы очистить оперативную память мозга.
            </span>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
            >
              Отмена
            </button>
            <button
              onClick={handleProcessAndSave}
              disabled={isProcessing || !rawText.trim()}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-indigo-500/25 transition active:scale-95 disabled:opacity-50"
            >
              <ListPlus className="w-4 h-4" />
              <span>{isProcessing ? 'Разбор...' : 'Выгрузить в задачи'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
