import React, { useState, useEffect } from 'react';
import { X, Target, Calendar, Plus, Trash2, CheckCircle2, TrendingUp } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import type { Goal, KeyResult } from '../types';

interface GoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  goal: Goal | null;
  defaultHorizon?: 'year' | 'quarter' | 'month';
  onSave: (goalData: Partial<Goal>) => Promise<void>;
}

export const GoalModal: React.FC<GoalModalProps> = ({
  isOpen,
  onClose,
  goal,
  defaultHorizon = 'month',
  onSave
}) => {
  const { playPop } = useSound();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [horizon, setHorizon] = useState<'year' | 'quarter' | 'month'>(defaultHorizon);
  const [category, setCategory] = useState('Карьера & Бизнес');
  const [targetDate, setTargetDate] = useState('');
  const [color, setColor] = useState('emerald');
  const [keyResults, setKeyResults] = useState<KeyResult[]>([]);
  const [newKrTitle, setNewKrTitle] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (goal) {
      setTitle(goal.title || '');
      setDescription(goal.description || '');
      setHorizon(goal.horizon || defaultHorizon);
      setCategory(goal.category || 'Карьера & Бизнес');
      setTargetDate(goal.target_date ? goal.target_date.split('T')[0] : '');
      setColor(goal.color || 'emerald');
      setKeyResults(goal.key_results || []);
    } else {
      setTitle('');
      setDescription('');
      setHorizon(defaultHorizon);
      setCategory('Карьера & Бизнес');
      setTargetDate('');
      setColor('emerald');
      setKeyResults([]);
    }
  }, [goal, defaultHorizon, isOpen]);

  if (!isOpen) return null;

  const categories = [
    'Карьера & Бизнес',
    'Здоровье & Энергия',
    'Финансы & Капитал',
    'Личная жизнь & Семья',
    'Обучение & Развитие',
    'Яркость жизни & Путешествия'
  ];

  const colors = [
    { id: 'emerald', label: 'Изумрудный', bg: 'bg-emerald-500' },
    { id: 'amber', label: 'Янтарный', bg: 'bg-amber-500' },
    { id: 'indigo', label: 'Индиго', bg: 'bg-indigo-500' },
    { id: 'rose', label: 'Розовый', bg: 'bg-rose-500' },
    { id: 'purple', label: 'Фиолетовый', bg: 'bg-purple-500' }
  ];

  const handleAddKr = () => {
    if (!newKrTitle.trim()) return;
    playPop();
    setKeyResults([
      ...keyResults,
      {
        id: 'kr-' + Date.now(),
        title: newKrTitle.trim(),
        current: 0,
        target: 100,
        unit: '%',
        is_completed: false
      }
    ]);
    setNewKrTitle('');
  };

  const handleToggleKr = (id: string) => {
    playPop();
    setKeyResults(keyResults.map(kr => {
      if (kr.id === id) {
        const next = !kr.is_completed;
        return { ...kr, is_completed: next, current: next ? kr.target : 0 };
      }
      return kr;
    }));
  };

  const handleDeleteKr = (id: string) => {
    setKeyResults(keyResults.filter(kr => kr.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    // Calculate automatic progress from Key Results
    let progress = 0;
    if (keyResults.length > 0) {
      const completedCount = keyResults.filter(kr => kr.is_completed).length;
      progress = Math.round((completedCount / keyResults.length) * 100);
    }

    setSaving(true);
    await onSave({
      ...(goal ? { id: goal.id } : {}),
      title: title.trim(),
      description: description.trim(),
      horizon,
      category,
      target_date: targetDate || null,
      progress,
      color,
      key_results: keyResults,
      status: progress >= 100 ? 'completed' : 'in_progress'
    });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight mb-5">
          {goal ? 'Редактировать цель' : 'Новая стратегическая цель'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Horizon Selector (Year / Quarter / Month) */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-2">
              Горизонт планирования:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'year', label: '🌟 Год (2026)' },
                { id: 'quarter', label: '🎯 Квартал (Q3/Q4)' },
                { id: 'month', label: '⚡ Месяц' }
              ].map((h) => (
                <button
                  type="button"
                  key={h.id}
                  onClick={() => {
                    setHorizon(h.id as 'year' | 'quarter' | 'month');
                    playPop();
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-semibold transition ${
                    horizon === h.id
                      ? 'bg-stone-900 text-white dark:bg-white dark:text-zinc-900 shadow-sm'
                      : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400 hover:bg-stone-200'
                  }`}
                >
                  {h.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Формулировка цели *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Например: Запустить новый флагманский продукт или пробежать полумарафон"
              className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Category & Target Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Сфера жизни
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Срок реализации
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Key Results / OKR Milestones */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider">
                Ключевые результаты (OKR / Чекпоинты):
              </label>
              <span className="text-[11px] text-stone-400">
                {keyResults.filter(k => k.is_completed).length} из {keyResults.length} выполнено
              </span>
            </div>

            <div className="space-y-1.5 mb-2 max-h-36 overflow-y-auto">
              {keyResults.map((kr) => (
                <div
                  key={kr.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-stone-50 dark:bg-zinc-800/60 border border-stone-200/60 dark:border-zinc-700/60 text-xs"
                >
                  <button
                    type="button"
                    onClick={() => handleToggleKr(kr.id)}
                    className="flex items-center gap-2 text-left truncate flex-1"
                  >
                    <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                      kr.is_completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-300 dark:border-zinc-600'
                    }`}>
                      {kr.is_completed && <CheckCircle2 className="w-3 h-3" />}
                    </div>
                    <span className={`truncate ${kr.is_completed ? 'line-through text-stone-400' : 'text-stone-800 dark:text-zinc-200'}`}>
                      {kr.title}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteKr(kr.id)}
                    className="p-1 text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newKrTitle}
                onChange={(e) => setNewKrTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddKr();
                  }
                }}
                placeholder="+ Добавить измеримый результат"
                className="flex-1 px-3 py-2 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={handleAddKr}
                className="px-3 py-2 rounded-xl bg-stone-200 dark:bg-zinc-700 text-stone-800 dark:text-zinc-200 text-xs font-semibold hover:bg-stone-300"
              >
                Добавить
              </button>
            </div>
          </div>

          {/* Color Tag & Description */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-2">
              Цветовая метка:
            </label>
            <div className="flex items-center gap-2">
              {colors.map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => setColor(c.id)}
                  className={`w-7 h-7 rounded-full ${c.bg} flex items-center justify-center transition-all ${
                    color === c.id ? 'ring-2 ring-offset-2 ring-stone-900 dark:ring-white scale-110' : 'opacity-70 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Зачем эта цель важна (Мотивация):
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Что изменится в жизни после достижения? Какой результат принесет радость?"
              className="w-full px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={saving || !title.trim()}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-emerald-500/25 transition active:scale-95 disabled:opacity-50"
            >
              {saving ? 'Сохранение...' : goal ? 'Обновить цель' : 'Сохранить цель'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
