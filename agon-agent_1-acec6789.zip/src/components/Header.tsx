import React, { useState } from 'react';
import { Sparkles, Flame, Volume2, VolumeX, Moon, Sun, Plus, Timer, User, CheckCircle2, Palette } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import type { EnergyLog } from '../types';

interface HeaderProps {
  currentEnergyLog: EnergyLog | null;
  onOpenEnergyCheckin: () => void;
  onOpenBrainDump: () => void;
  onOpenTimer: () => void;
  onOpenAuth: () => void;
  onOpenNewTask: () => void;
  tasksCompletedTodayCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentEnergyLog,
  onOpenEnergyCheckin,
  onOpenBrainDump,
  onOpenTimer,
  onOpenAuth,
  onOpenNewTask,
  tasksCompletedTodayCount
}) => {
  const { isMuted, toggleMute } = useSound();
  const { theme, setTheme, moodColorMode } = useTheme();
  const { user, isDemoUser, signOut } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);

  // Time-aware warm greeting in Russian
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'Доброе утро';
    if (hour >= 12 && hour < 18) return 'Продуктивного дня';
    if (hour >= 18 && hour < 23) return 'Уютного вечера';
    return 'Спокойной ночи';
  };

  const getEnergyBadge = () => {
    if (!currentEnergyLog) {
      return {
        label: 'Чек-ин энергии',
        icon: '⚡',
        paletteName: 'Яркие тона',
        color: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-200 dark:border-amber-800'
      };
    }
    const level = currentEnergyLog.energy_level;
    if (level >= 4) {
      return {
        label: `Энергия ${level}/5 • ${currentEnergyLog.mood}`,
        icon: '⚡',
        paletteName: 'Яркая палитра',
        color: 'bg-gradient-to-r from-amber-500/15 to-orange-500/15 text-amber-900 dark:text-amber-200 border-amber-400 dark:border-amber-700 font-bold'
      };
    }
    return {
      label: `Энергия ${level}/5 • ${currentEnergyLog.mood}`,
      icon: level === 3 ? '🌤️' : '🌿',
      paletteName: 'Успокаивающая палитра',
      color: 'bg-gradient-to-r from-teal-500/15 to-sky-500/15 text-teal-900 dark:text-teal-200 border-teal-300 dark:border-teal-700 font-bold'
    };
  };

  const badge = getEnergyBadge();
  const isVibrant = moodColorMode === 'vibrant';

  return (
    <header className="sticky top-0 z-30 backdrop-blur-md bg-white/85 dark:bg-zinc-900/85 border-b border-stone-200/80 dark:border-zinc-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-3">
          
          {/* Left: Branding & Greeting */}
          <div className="flex items-center gap-3 min-w-0">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-md shrink-0 transition-all duration-500 ${
              isVibrant
                ? 'bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 shadow-amber-500/30'
                : 'bg-gradient-to-tr from-teal-500 via-emerald-500 to-sky-600 shadow-teal-500/20'
            }`}>
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-base sm:text-lg text-stone-900 dark:text-white tracking-tight truncate">
                  {getGreeting()}
                </span>
                <span className={`hidden sm:inline-block text-xs font-medium px-2 py-0.5 rounded-full ${
                  isVibrant
                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                    : 'bg-teal-500/10 text-teal-700 dark:text-teal-300'
                }`}>
                  {new Date().toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' })}
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-zinc-400 truncate flex items-center gap-1.5">
                <span>Ясность в мыслях • Спокойствие в действиях</span>
              </p>
            </div>
          </div>

          {/* Center: Dynamic Mood Energy Badge & Palette Indicator */}
          <div className="hidden md:flex items-center gap-2.5">
            <button
              onClick={onOpenEnergyCheckin}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs transition-all hover:scale-105 active:scale-95 shadow-xs border ${badge.color}`}
              title="Нажмите, чтобы изменить настроение и цветовую гамму приложения"
            >
              <span>{badge.icon}</span>
              <span>{badge.label}</span>
              <span className="opacity-70 text-[10px]">({badge.paletteName})</span>
            </button>

            <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-xs font-medium ${
              isVibrant
                ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/60 text-amber-700 dark:text-amber-300'
                : 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-800/60 text-teal-700 dark:text-teal-300'
            }`}>
              <Flame className={`w-3.5 h-3.5 ${isVibrant ? 'text-amber-500 fill-amber-500' : 'text-teal-500 fill-teal-500'}`} />
              <span>7 дней в фокусе</span>
            </div>

            {tasksCompletedTodayCount > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-xs font-medium text-emerald-700 dark:text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>{tasksCompletedTodayCount} готово</span>
              </div>
            )}
          </div>

          {/* Right: Actions, Flow Timer, Brain Dump, Audio & Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Quick Brain Dump Button */}
            <button
              onClick={onOpenBrainDump}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-stone-700 dark:text-zinc-200 bg-stone-100 dark:bg-zinc-800 hover:bg-stone-200 dark:hover:bg-zinc-700 rounded-xl transition shadow-xs"
              title="Выгрузить мысли из головы (Brain Dump)"
            >
              <span>⚡ Сброс мыслей</span>
            </button>

            {/* Quick Flow Timer Trigger */}
            <button
              onClick={onOpenTimer}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-2 text-xs font-medium rounded-xl transition shadow-xs border ${
                isVibrant
                  ? 'text-amber-900 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800 hover:bg-amber-100'
                  : 'text-teal-900 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/60 border-teal-300 dark:border-teal-800 hover:bg-teal-100'
              }`}
              title="Фокус-таймер (Помодоро)"
            >
              <Timer className={`w-4 h-4 ${isVibrant ? 'text-amber-600 dark:text-amber-400' : 'text-teal-600 dark:text-teal-400'}`} />
              <span className="hidden sm:inline">Фокус</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={toggleMute}
              className={`p-2 rounded-xl border text-stone-600 dark:text-zinc-300 hover:bg-stone-100 dark:hover:bg-zinc-800 transition ${
                isMuted ? 'border-stone-200 dark:border-zinc-800 opacity-60' : isVibrant ? 'border-amber-300 bg-amber-50/50 dark:bg-amber-950/30' : 'border-teal-300 bg-teal-50/50 dark:bg-teal-950/30'
              }`}
              title={isMuted ? 'Включить звуки' : 'Звуки включены'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className={`w-4 h-4 ${isVibrant ? 'text-amber-600' : 'text-teal-600'}`} />}
            </button>

            {/* Theme Toggle */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'warm' : theme === 'warm' ? 'sage' : 'dark')}
              className="p-2 rounded-xl border border-stone-200 dark:border-zinc-800 text-stone-600 dark:text-zinc-300 hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
              title={`Тема: ${theme === 'warm' ? 'Теплая' : theme === 'sage' ? 'Шалфей' : 'Ночь'}`}
            >
              {theme === 'dark' ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
            </button>

            {/* New Task Plus Button */}
            <button
              onClick={onOpenNewTask}
              className={`flex items-center gap-1 px-3 sm:px-3.5 py-2 rounded-xl font-semibold text-xs sm:text-sm text-white shadow-md hover:opacity-95 active:scale-95 transition ${
                isVibrant
                  ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 shadow-amber-500/25'
                  : 'bg-gradient-to-r from-teal-600 via-emerald-600 to-sky-600 shadow-teal-500/20'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Задача</span>
            </button>

            {/* Profile / Auth Menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="w-9 h-9 rounded-xl border border-stone-200 dark:border-zinc-800 flex items-center justify-center bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-200 hover:ring-2 ring-amber-400/50 transition"
                title="Профиль"
              >
                {user ? (
                  <div className={`w-6 h-6 rounded-full text-white text-xs font-bold flex items-center justify-center ${
                    isVibrant ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-gradient-to-r from-teal-500 to-sky-500'
                  }`}>
                    {(user.email?.[0] || 'U').toUpperCase()}
                  </div>
                ) : (
                  <User className="w-4 h-4" />
                )}
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white dark:bg-zinc-900 shadow-xl border border-stone-200 dark:border-zinc-800 p-2 z-50 text-xs">
                  {user || isDemoUser ? (
                    <div>
                      <div className="p-2 border-b border-stone-100 dark:border-zinc-800 mb-1">
                        <p className="font-semibold text-stone-900 dark:text-white truncate">
                          {user?.email || 'Демо-пользователь'}
                        </p>
                        <p className="text-stone-400 text-[11px]">
                          {isDemoUser ? 'Тестовый режим с облаком' : 'Синхронизация активна'}
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          onOpenEnergyCheckin();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 flex items-center justify-between"
                      >
                        <span>⚡ Энергетический чек-ин</span>
                        <Palette className="w-3.5 h-3.5 text-stone-400" />
                      </button>
                      <button
                        onClick={() => {
                          signOut();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400 mt-1"
                      >
                        Выйти
                      </button>
                    </div>
                  ) : (
                    <div className="p-1">
                      <p className="text-stone-500 dark:text-zinc-400 mb-2 px-1">Войдите для синхронизации на всех устройствах:</p>
                      <button
                        onClick={() => {
                          onOpenAuth();
                          setShowUserMenu(false);
                        }}
                        className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-medium rounded-xl text-center"
                      >
                        Войти или Создать
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Mobile Subheader with Energy Checkin Trigger */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-stone-100 dark:border-zinc-800/80 gap-2">
          <button
            onClick={onOpenEnergyCheckin}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${badge.color}`}
          >
            <span>{badge.icon}</span>
            <span className="truncate">{badge.label}</span>
          </button>
          
          <button
            onClick={onOpenBrainDump}
            className={`flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full ${
              isVibrant
                ? 'text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40'
                : 'text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40'
            }`}
          >
            <span>⚡ Сброс мыслей</span>
          </button>
        </div>

      </div>
    </header>
  );
};
