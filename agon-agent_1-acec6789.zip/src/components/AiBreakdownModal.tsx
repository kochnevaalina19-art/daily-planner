import React, { useState, useEffect } from 'react';
import { X, Wand2, Sparkles, Plus, Clock, Check, ArrowRight } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';

interface AiBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTaskTitle: string;
  onImportStepsAsTasks: (steps: Array<{ title: string; estimated_minutes: number }>) => Promise<void>;
}

interface Step {
  title: string;
  estimated_minutes: number;
}

export const AiBreakdownModal: React.FC<AiBreakdownModalProps> = ({
  isOpen,
  onClose,
  initialTaskTitle,
  onImportStepsAsTasks
}) => {
  const { playComplete, playPop } = useSound();
  const [taskTitle, setTaskTitle] = useState(initialTaskTitle);
  const [loading, setLoading] = useState(false);
  const [steps, setSteps] = useState<Step[]>([]);
  const [advice, setAdvice] = useState('');
  const [estimatedTotal, setEstimatedTotal] = useState(60);

  useEffect(() => {
    if (initialTaskTitle) {
      setTaskTitle(initialTaskTitle);
      fetchBreakdown(initialTaskTitle);
    }
  }, [initialTaskTitle, isOpen]);

  const fetchBreakdown = async (titleToBreak: string) => {
    if (!titleToBreak.trim()) return;
    setLoading(true);
    try {
      const res = await fetch('/api/ai-breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskTitle: titleToBreak })
      });
      const data = await res.json();
      if (data && data.steps) {
        setSteps(data.steps);
        setAdvice(data.advice || '');
        setEstimatedTotal(data.estimatedTotalMinutes || 60);
      }
    } catch (err) {
      console.error('Breakdown error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleImport = async () => {
    if (steps.length === 0) return;
    playComplete();
    await onImportStepsAsTasks(steps);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center text-2xl shadow-inner">
            <Wand2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight">
              Умная декомпозиция задачи
            </h2>
            <p className="text-xs text-stone-500 dark:text-zinc-400">
              Снимаем страх перед большой задачей: превращаем её в легкие шаги по 10-25 минут
            </p>
          </div>
        </div>

        {/* Task Input */}
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={taskTitle}
            onChange={(e) => setTaskTitle(e.target.value)}
            placeholder="Какую задачу разбить на шаги?"
            className="flex-1 px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <button
            type="button"
            onClick={() => fetchBreakdown(taskTitle)}
            disabled={loading || !taskTitle.trim()}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold transition active:scale-95 disabled:opacity-50"
          >
            {loading ? 'Анализ...' : 'Разбить'}
          </button>
        </div>

        {loading ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-stone-500 dark:text-zinc-400 font-medium">
              Анализируем задачу и готовим бережную пошаговую стратегию...
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {advice && (
              <div className="p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50 text-xs text-purple-900 dark:text-purple-200 leading-relaxed">
                {advice}
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-stone-400 uppercase tracking-wider">
                <span>Пошаговый план ({steps.length} шагов):</span>
                <span>~ {estimatedTotal} минут суммарно</span>
              </div>

              {steps.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-zinc-800/70 border border-stone-200/60 dark:border-zinc-700/60 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span className="font-medium text-stone-800 dark:text-zinc-200">
                      {step.title}
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400 shrink-0 ml-2">
                    {step.estimated_minutes} мин
                  </span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
              >
                Отмена
              </button>
              <button
                onClick={handleImport}
                disabled={steps.length === 0}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-purple-500/25 transition active:scale-95 disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                <span>Добавить шаги в задачи</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
