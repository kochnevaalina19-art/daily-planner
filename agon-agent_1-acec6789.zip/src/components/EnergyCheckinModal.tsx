import React, { useState, useEffect } from 'react';
import { X, Sparkles, Palette } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import { useTheme } from '../contexts/ThemeContext';
import type { EnergyLog } from '../types';

interface EnergyCheckinModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLog: EnergyLog | null;
  onSave: (log: Partial<EnergyLog>) => Promise<void>;
}

export const EnergyCheckinModal: React.FC<EnergyCheckinModalProps> = ({
  isOpen,
  onClose,
  currentLog,
  onSave
}) => {
  const { playPop, playBell } = useSound();
  const { setEnergyLevel: setGlobalEnergyLevel } = useTheme();

  const [energyLevel, setEnergyLevel] = useState<number>(currentLog?.energy_level || 4);
  const [mood, setMood] = useState<string>(currentLog?.mood || 'Вдохновение');
  const [focusState, setFocusState] = useState<string>(currentLog?.focus_state || 'Глубокий фокус (Deep Work)');
  const [note, setNote] = useState<string>(currentLog?.note || '');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (currentLog) {
      setEnergyLevel(currentLog.energy_level || 4);
      setMood(currentLog.mood || 'Вдохновение');
      setFocusState(currentLog.focus_state || 'Глубокий фокус (Deep Work)');
      setNote(currentLog.note || '');
    }
  }, [currentLog, isOpen]);

  if (!isOpen) return null;

  const isVibrant = energyLevel >= 4;

  const moodOptions = isVibrant
    ? [
        { label: 'Вдохновение', emoji: '✨' },
        { label: 'Решимость', emoji: '🔥' },
        { label: 'Поток', emoji: '🌊' },
        { label: 'Радость', emoji: '💛' }
      ]
    : [
        { label: 'Спокойствие', emoji: '🌿' },
        { label: 'Легкая усталость', emoji: '🌤️' },
        { label: 'Перегруз / Стресс', emoji: '⚡' },
        { label: 'Потребность в отдыхе', emoji: '🛋️' }
      ];

  const focusOptions = [
    'Глубокий фокус (Deep Work)',
    'Быстрый ритм (Звонки и задачи)',
    'Бережный режим (Минимум дел)',
    'Творческий поиск (Идеи и планы)'
  ];

  const getAdviceByEnergy = (level: number) => {
    switch (level) {
      case 5:
        return {
          title: '⚡ Пик продуктивности & Яркая палитра!',
          desc: 'Идеальное время для самой сложной или творческой задачи. Цвета приложения стали яркими и энергичными для максимального драйва.'
        };
      case 4:
        return {
          title: '🚀 Отличный заряд & Яркие тона!',
          desc: 'Сконцентрируйся на 2-3 ключевых задачах утра. Яркая палитра поддерживает тонус и уверенность.'
        };
      case 3:
        return {
          title: '🌤️ Умеренный темп & Успокаивающая палитра',
          desc: 'Светлые, мягкие пастельные тона снижают нагрузку на зрение. Сделай 1 важную задачу, а остальное — легкая рутина.'
        };
      case 2:
        return {
          title: '🌱 Бережный режим & Мягкие тона',
          desc: 'Энергия на спаде. Успокаивающая цветовая гамма создает ощущение безопасности. Делегируй и выбери 1 микро-дело.'
        };
      default:
        return {
          title: '🛋️ Время восстановления & Дзен-палитра',
          desc: 'Светлые, умиротворяющие тона помогают расслабиться. Сбрось лишние дела в бэклог и обязательно отдохни.'
        };
    }
  };

  const advice = getAdviceByEnergy(energyLevel);

  const handleLevelChange = (lvl: number) => {
    setEnergyLevel(lvl);
    setGlobalEnergyLevel(lvl);
    playPop();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    playBell();
    setGlobalEnergyLevel(energyLevel);
    await onSave({
      energy_level: energyLevel,
      mood,
      focus_state: focusState,
      note,
      date: new Date().toISOString().split('T')[0]
    });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto transition-all">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner transition-colors duration-300 ${
            isVibrant ? 'bg-amber-500/15 text-amber-600' : 'bg-teal-500/15 text-teal-600'
          }`}>
            {energyLevel >= 4 ? '⚡' : energyLevel === 3 ? '🌤️' : '🌿'}
          </div>
          <div>
            <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight">
              Энергетический чек-ин
            </h2>
            <p className="text-xs text-stone-500 dark:text-zinc-400">
              Цветовая гамма приложения адаптируется под ваше настроение
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Energy Level Selector with Dynamic Palette Preview */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider">
                Уровень энергии & настроения: {energyLevel} из 5
              </label>
              <div className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-0.5 rounded-full ${
                isVibrant
                  ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200'
                  : 'bg-teal-100 text-teal-900 dark:bg-teal-950 dark:text-teal-200'
              }`}>
                <Palette className="w-3.5 h-3.5" />
                <span>{isVibrant ? 'Яркие цвета (4-5)' : 'Светлые успокаивающие (1-3)'}</span>
              </div>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((lvl) => {
                const isSelected = energyLevel === lvl;
                const lvlIsVibrant = lvl >= 4;

                return (
                  <button
                    type="button"
                    key={lvl}
                    onClick={() => handleLevelChange(lvl)}
                    className={`py-3 rounded-2xl font-bold text-sm flex flex-col items-center gap-1 transition-all ${
                      isSelected
                        ? lvlIsVibrant
                          ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/30 scale-105'
                          : 'bg-teal-600 text-white shadow-lg shadow-teal-600/30 scale-105'
                        : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400 hover:bg-stone-200 dark:hover:bg-zinc-700'
                    }`}
                  >
                    <span className="text-base">
                      {lvl === 5 ? '⚡' : lvl === 4 ? '🚀' : lvl === 3 ? '🌤️' : lvl === 2 ? '🌱' : '😴'}
                    </span>
                    <span>{lvl}</span>
                  </button>
                );
              })}
            </div>
            
            <div className="flex justify-between text-[11px] text-stone-400 font-medium px-1 mt-1.5">
              <span>Светлые, успокаивающие тона (1–3)</span>
              <span>Яркие, насыщенные тона (4–5)</span>
            </div>
          </div>

          {/* Adaptive supportive advice box with dynamic palette styling */}
          <div className={`p-4 rounded-2xl border transition-all duration-300 ${
            isVibrant
              ? 'bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-rose-500/10 border-amber-300 dark:border-amber-900/40 text-amber-950 dark:text-amber-200'
              : 'bg-gradient-to-br from-teal-500/10 via-sky-500/5 to-emerald-500/10 border-teal-300 dark:border-teal-900/40 text-teal-950 dark:text-teal-200'
          }`}>
            <h4 className="text-xs font-bold flex items-center gap-1.5 mb-1">
              <Sparkles className="w-4 h-4" />
              {advice.title}
            </h4>
            <p className="text-xs leading-relaxed opacity-90">
              {advice.desc}
            </p>
          </div>

          {/* Mood tags */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-2">
              Текущее состояние & чувство:
            </label>
            <div className="flex flex-wrap gap-2">
              {moodOptions.map((item) => (
                <button
                  type="button"
                  key={item.label}
                  onClick={() => {
                    setMood(item.label);
                    playPop();
                  }}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition flex items-center gap-1.5 ${
                    mood === item.label
                      ? isVibrant
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'bg-teal-600 text-white shadow-xs'
                      : 'bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 dark:hover:bg-zinc-700'
                  }`}
                >
                  <span>{item.emoji}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Focus Mode Target */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-2">
              Желаемый фокус на сегодня:
            </label>
            <select
              value={focusState}
              onChange={(e) => setFocusState(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              {focusOptions.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>

          {/* Note / Intention */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Намерение дня или мысль:
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Например: Сделать главное до 15:00 и вечер посвятить отдыху"
              className="w-full px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={saving}
              className={`px-6 py-2.5 rounded-xl text-white text-xs sm:text-sm font-semibold shadow-lg transition active:scale-95 disabled:opacity-50 ${
                isVibrant
                  ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/25'
                  : 'bg-teal-600 hover:bg-teal-700 shadow-teal-600/25'
              }`}
            >
              {saving ? 'Сохранение...' : 'Зафиксировать состояние и палитру'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
