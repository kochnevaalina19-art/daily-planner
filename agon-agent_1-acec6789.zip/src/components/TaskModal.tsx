import React, { useState, useEffect } from 'react';
import { X, Sparkles, Clock, Target, Flag, CheckSquare, Plus, Trash2, Wand2 } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import type { Task, Priority, TaskHorizon, Goal, Subtask } from '../types';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
  goals: Goal[];
  onSave: (taskData: Partial<Task>) => Promise<void>;
  onOpenAiBreakdown?: (taskTitle: string) => void;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  task,
  goals,
  onSave,
  onOpenAiBreakdown
}) => {
  const { playPop } = useSound();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isFocus, setIsFocus] = useState(false);
  const [priority, setPriority] = useState<Priority>('medium');
  const [horizon, setHorizon] = useState<TaskHorizon>('day');
  const [goalId, setGoalId] = useState<number | null>(null);
  const [dueDate, setDueDate] = useState<string>('');
  const [estimatedMinutes, setEstimatedMinutes] = useState<number>(30);
  const [subtasks, setSubtasks] = useState<Subtask[]>([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (task) {
      setTitle(task.title || '');
      setDescription(task.description || '');
      setIsFocus(Boolean(task.is_focus));
      setPriority(task.priority || 'medium');
      setHorizon(task.horizon || 'day');
      setGoalId(task.goal_id || null);
      setDueDate(task.due_date ? task.due_date.split('T')[0] : '');
      setEstimatedMinutes(task.estimated_minutes || 30);
      setSubtasks(task.subtasks || []);
    } else {
      setTitle('');
      setDescription('');
      setIsFocus(false);
      setPriority('medium');
      setHorizon('day');
      setGoalId(null);
      setDueDate(new Date().toISOString().split('T')[0]);
      setEstimatedMinutes(30);
      setSubtasks([]);
    }
  }, [task, isOpen]);

  if (!isOpen) return null;

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return;
    playPop();
    setSubtasks([
      ...subtasks,
      {
        id: 'st-' + Date.now(),
        title: newSubtaskTitle.trim(),
        is_completed: false
      }
    ]);
    setNewSubtaskTitle('');
  };

  const handleToggleSubtask = (id: string) => {
    playPop();
    setSubtasks(subtasks.map(s => s.id === id ? { ...s, is_completed: !s.is_completed } : s));
  };

  const handleDeleteSubtask = (id: string) => {
    setSubtasks(subtasks.filter(s => s.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setSaving(true);
    await onSave({
      ...(task ? { id: task.id } : {}),
      title: title.trim(),
      description: description.trim(),
      is_focus: isFocus,
      priority,
      horizon,
      goal_id: goalId,
      due_date: dueDate || null,
      estimated_minutes: Number(estimatedMinutes) || 30,
      subtasks
    });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight mb-5">
          {task ? 'Редактировать задачу' : 'Новая задача'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Название задачи *
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Что конкретно нужно сделать?"
                className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* AI Decomposition button helper */}
          {title.trim().length > 3 && onOpenAiBreakdown && (
            <button
              type="button"
              onClick={() => onOpenAiBreakdown(title)}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40 border border-indigo-200 dark:border-indigo-800/60 text-xs font-semibold text-indigo-700 dark:text-indigo-300 hover:scale-[1.01] active:scale-95 transition"
            >
              <Wand2 className="w-4 h-4 text-indigo-500 animate-spin-slow" />
              <span>Умная декомпозиция: разбить на 4 простых микро-шага</span>
            </button>
          )}

          {/* Focus Toggle (Rule of 3 Hero) */}
          <div className="p-3.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center text-sm font-bold">
                ⭐
              </div>
              <div>
                <p className="text-xs font-bold text-amber-950 dark:text-amber-200">
                  Фокус дня (Главная задача)
                </p>
                <p className="text-[11px] text-amber-800 dark:text-amber-400">
                  Поместить в топ-3 ключевых дел на сегодня
                </p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isFocus}
                onChange={(e) => setIsFocus(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
          </div>

          {/* Priority & Estimated Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Приоритет
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value="low">🌱 Низкий (Рутина)</option>
                <option value="medium">🌤️ Средний (Обычный)</option>
                <option value="high">🔥 Высокий (Важно)</option>
                <option value="urgent">⚡ Срочно (ASAP)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Оценка времени
              </label>
              <div className="relative">
                <input
                  type="number"
                  min={5}
                  max={480}
                  step={5}
                  value={estimatedMinutes}
                  onChange={(e) => setEstimatedMinutes(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <span className="absolute right-3 top-2.5 text-xs text-stone-400 pointer-events-none">
                  мин
                </span>
              </div>
            </div>
          </div>

          {/* Goal Linker & Due Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Связать с целью
              </label>
              <select
                value={goalId || ''}
                onChange={(e) => setGoalId(e.target.value ? Number(e.target.value) : null)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 truncate"
              >
                <option value="">Без привязки к цели</option>
                {goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    🎯 {g.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
                Дата выполнения
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Subtasks checklist */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Подзадачи (Чек-лист):
            </label>
            
            <div className="space-y-1.5 mb-2 max-h-36 overflow-y-auto">
              {subtasks.map((st) => (
                <div
                  key={st.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-stone-50 dark:bg-zinc-800/60 border border-stone-200/60 dark:border-zinc-700/60 text-xs"
                >
                  <button
                    type="button"
                    onClick={() => handleToggleSubtask(st.id)}
                    className="flex items-center gap-2 text-left truncate flex-1"
                  >
                    <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                      st.is_completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-300 dark:border-zinc-600'
                    }`}>
                      {st.is_completed && <CheckSquare className="w-3 h-3" />}
                    </div>
                    <span className={`truncate ${st.is_completed ? 'line-through text-stone-400' : 'text-stone-800 dark:text-zinc-200'}`}>
                      {st.title}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteSubtask(st.id)}
                    className="p-1 text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSubtask();
                  }
                }}
                placeholder="+ Добавить подзадачу"
                className="flex-1 px-3 py-2 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="button"
                onClick={handleAddSubtask}
                className="px-3 py-2 rounded-xl bg-stone-200 dark:bg-zinc-700 text-stone-800 dark:text-zinc-200 text-xs font-semibold hover:bg-stone-300"
              >
                Добавить
              </button>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Заметки / Ссылки к задаче
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Дополнительные детали, ссылки на документы..."
              className="w-full px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={saving || !title.trim()}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-amber-500/25 transition active:scale-95 disabled:opacity-50"
            >
              {saving ? 'Сохранение...' : task ? 'Обновить' : 'Создать задачу'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
