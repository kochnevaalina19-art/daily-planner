import React, { useState, useEffect } from 'react';
import { X, Pin, CheckSquare, Plus, Trash2, ArrowRight } from 'lucide-react';
import { useSound } from '../contexts/SoundContext';
import type { Note, NoteChecklistItem } from '../types';

interface NoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  note: Note | null;
  onSave: (noteData: Partial<Note>) => Promise<void>;
  onConvertToTask?: (taskTitle: string) => void;
}

export const NoteModal: React.FC<NoteModalProps> = ({
  isOpen,
  onClose,
  note,
  onSave,
  onConvertToTask
}) => {
  const { playPop } = useSound();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [isPinned, setIsPinned] = useState(false);
  const [color, setColor] = useState('amber');
  const [checklist, setChecklist] = useState<NoteChecklistItem[]>([]);
  const [newCheckItem, setNewCheckItem] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (note) {
      setTitle(note.title || '');
      setContent(note.content || '');
      setTagsInput((note.tags || []).join(', '));
      setIsPinned(Boolean(note.is_pinned));
      setColor(note.color || 'amber');
      setChecklist(note.checklist || []);
    } else {
      setTitle('');
      setContent('');
      setTagsInput('Идеи, Мысли');
      setIsPinned(false);
      setColor('amber');
      setChecklist([]);
    }
  }, [note, isOpen]);

  if (!isOpen) return null;

  const handleAddCheckItem = () => {
    if (!newCheckItem.trim()) return;
    playPop();
    setChecklist([
      ...checklist,
      {
        id: 'chk-' + Date.now(),
        text: newCheckItem.trim(),
        checked: false
      }
    ]);
    setNewCheckItem('');
  };

  const handleToggleCheckItem = (id: string) => {
    playPop();
    setChecklist(checklist.map(item => item.id === id ? { ...item, checked: !item.checked } : item));
  };

  const handleDeleteCheckItem = (id: string) => {
    setChecklist(checklist.filter(item => item.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    setSaving(true);
    await onSave({
      ...(note ? { id: note.id } : {}),
      title: title.trim(),
      content: content.trim(),
      tags,
      is_pinned: isPinned,
      color,
      checklist
    });
    setSaving(false);
    onClose();
  };

  const colors = [
    { id: 'amber', bg: 'bg-amber-400' },
    { id: 'rose', bg: 'bg-rose-400' },
    { id: 'sky', bg: 'bg-sky-400' },
    { id: 'emerald', bg: 'bg-emerald-400' },
    { id: 'purple', bg: 'bg-purple-400' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-stone-900 dark:text-white tracking-tight">
            {note ? 'Редактировать заметку' : 'Новая заметка / Мысль'}
          </h2>
          <button
            type="button"
            onClick={() => setIsPinned(!isPinned)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
              isPinned
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                : 'text-stone-400 hover:bg-stone-100 dark:hover:bg-zinc-800'
            }`}
          >
            <Pin className={`w-4 h-4 ${isPinned ? 'fill-amber-500' : ''}`} />
            <span>{isPinned ? 'Закреплено' : 'Закрепить'}</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Заголовок заметки *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Инсайт, конспект встречи, список покупок..."
              className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Color selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Цвет:</span>
            {colors.map((c) => (
              <button
                type="button"
                key={c.id}
                onClick={() => setColor(c.id)}
                className={`w-6 h-6 rounded-full ${c.bg} transition-all ${
                  color === c.id ? 'ring-2 ring-offset-2 ring-stone-900 dark:ring-white scale-110' : 'opacity-60 hover:opacity-100'
                }`}
              />
            ))}
          </div>

          {/* Content */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Текст заметки / Смыслы
            </label>
            <textarea
              rows={5}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Пиши свободно: идеи, цитаты, выжимки, полезные ссылки..."
              className="w-full px-4 py-3 rounded-2xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs sm:text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed"
            />
          </div>

          {/* Checklist inside note */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Пункты списка (чек-лист):
            </label>
            
            <div className="space-y-1.5 mb-2 max-h-36 overflow-y-auto">
              {checklist.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-stone-50 dark:bg-zinc-800/60 border border-stone-200/60 dark:border-zinc-700/60 text-xs gap-2"
                >
                  <button
                    type="button"
                    onClick={() => handleToggleCheckItem(item.id)}
                    className="flex items-center gap-2 text-left truncate flex-1"
                  >
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                      item.checked ? 'bg-amber-500 border-amber-500 text-white' : 'border-stone-300 dark:border-zinc-600'
                    }`}>
                      {item.checked && <CheckSquare className="w-3 h-3" />}
                    </div>
                    <span className={`truncate ${item.checked ? 'line-through text-stone-400' : 'text-stone-800 dark:text-zinc-200'}`}>
                      {item.text}
                    </span>
                  </button>

                  {/* Convert item to task action */}
                  {onConvertToTask && (
                    <button
                      type="button"
                      onClick={() => onConvertToTask(item.text)}
                      className="px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[10px] font-semibold flex items-center gap-1 hover:scale-105"
                      title="Превратить пункт в задачу"
                    >
                      <span>В задачу</span>
                      <ArrowRight className="w-2.5 h-2.5" />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleDeleteCheckItem(item.id)}
                    className="p-1 text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newCheckItem}
                onChange={(e) => setNewCheckItem(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCheckItem();
                  }
                }}
                placeholder="+ Добавить пункт списка"
                className="flex-1 px-3 py-2 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="button"
                onClick={handleAddCheckItem}
                className="px-3 py-2 rounded-xl bg-stone-200 dark:bg-zinc-700 text-stone-800 dark:text-zinc-200 text-xs font-semibold hover:bg-stone-300"
              >
                Добавить
              </button>
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider mb-1.5">
              Теги (через запятую)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Идеи, Книги, Маркетинг, Вдохновение..."
              className="w-full px-4 py-2.5 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50 dark:bg-zinc-800 text-stone-900 dark:text-white text-xs placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-zinc-400 text-xs font-medium hover:bg-stone-100 dark:hover:bg-zinc-800 transition"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={saving || !title.trim()}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-amber-500/25 transition active:scale-95 disabled:opacity-50"
            >
              {saving ? 'Сохранение...' : note ? 'Обновить' : 'Создать заметку'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
