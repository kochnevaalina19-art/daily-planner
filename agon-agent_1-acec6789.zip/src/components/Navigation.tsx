import React from 'react';
import { Sun, Calendar, Inbox, StickyNote, Target, CheckCircle2 } from 'lucide-react';
import type { ActiveTab } from '../types';

interface NavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  inboxCount: number;
  todayCount: number;
  scheduledCount: number;
  notesCount: number;
  goalsCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  inboxCount,
  todayCount,
  scheduledCount,
  notesCount,
  goalsCount
}) => {
  const tabs = [
    {
      id: 'today' as ActiveTab,
      label: 'Сегодня & Фокус',
      shortLabel: 'Сегодня',
      icon: Sun,
      badge: todayCount,
      color: 'from-amber-500 to-orange-500',
      activeText: 'text-amber-600 dark:text-amber-400'
    },
    {
      id: 'calendar' as ActiveTab,
      label: 'Календарь & Расписание',
      shortLabel: 'Календарь',
      icon: Calendar,
      badge: scheduledCount,
      color: 'from-sky-500 to-blue-500',
      activeText: 'text-sky-600 dark:text-sky-400'
    },
    {
      id: 'inbox' as ActiveTab,
      label: 'Входящие / Разбор',
      shortLabel: 'Входящие',
      icon: Inbox,
      badge: inboxCount,
      color: 'from-blue-500 to-indigo-500',
      activeText: 'text-indigo-600 dark:text-indigo-400'
    },
    {
      id: 'notes' as ActiveTab,
      label: 'Заметки & Идеи',
      shortLabel: 'Заметки',
      icon: StickyNote,
      badge: notesCount,
      color: 'from-rose-500 to-pink-500',
      activeText: 'text-rose-600 dark:text-rose-400'
    },
    {
      id: 'goals' as ActiveTab,
      label: 'Цели (Год, Квартал, Месяц)',
      shortLabel: 'Цели',
      icon: Target,
      badge: goalsCount,
      color: 'from-emerald-500 to-teal-500',
      activeText: 'text-emerald-600 dark:text-emerald-400'
    }
  ];

  return (
    <>
      {/* Desktop Navigation Tabs */}
      <div className="hidden sm:block max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-2">
        <div className="flex items-center justify-between bg-stone-100/80 dark:bg-zinc-800/60 p-1.5 rounded-2xl border border-stone-200/70 dark:border-zinc-700/60 shadow-xs">
          <div className="grid grid-cols-5 w-full gap-1.5">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center justify-center gap-2 py-2.5 px-2 rounded-xl font-medium text-xs md:text-sm transition-all duration-200 ${
                    isActive
                      ? 'bg-white dark:bg-zinc-900 text-stone-900 dark:text-white shadow-sm font-semibold'
                      : 'text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-200 hover:bg-white/40 dark:hover:bg-zinc-800/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? tab.activeText : ''}`} />
                  <span className="truncate">{tab.label}</span>
                  {tab.badge > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold shrink-0 ${
                        isActive
                          ? 'bg-stone-900 text-white dark:bg-white dark:text-zinc-900'
                          : 'bg-stone-200 dark:bg-zinc-700 text-stone-700 dark:text-zinc-300'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                  {isActive && (
                    <div className="absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-amber-400 to-rose-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Mobile Fixed Bottom Bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-lg border-t border-stone-200 dark:border-zinc-800 pb- safe">
        <div className="grid grid-cols-5 px-1 py-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl relative transition ${
                  isActive ? 'text-amber-600 dark:text-amber-400 font-semibold' : 'text-stone-500 dark:text-zinc-400'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5 mb-0.5" />
                  {tab.badge > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-amber-500 text-white text-[9px] font-bold px-1 py-0.2 rounded-full min-w-3.5 text-center">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-[9.5px] truncate max-w-full">{tab.shortLabel}</span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
};
