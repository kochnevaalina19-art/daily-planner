import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Volume2, Sparkles, CheckCircle2, Coffee, Flame } from 'lucide-react';
import { useSound, AmbientSound } from '../contexts/SoundContext';
import confetti from 'canvas-confetti';
import type { Task } from '../types';

interface FlowTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  onTaskCompleted?: (taskId: number) => Promise<void>;
}

export const FlowTimerModal: React.FC<FlowTimerModalProps> = ({
  isOpen,
  onClose,
  tasks,
  onTaskCompleted
}) => {
  const { playComplete, playBell, ambientSound, setAmbientSound } = useSound();
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [duration, setDuration] = useState<number>(25 * 60); // 25 min default
  const [timeLeft, setTimeLeft] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null);

  // Set default selected task if focus tasks exist
  useEffect(() => {
    if (tasks.length > 0 && selectedTaskId === null) {
      const focus = tasks.find(t => t.is_focus && !t.is_completed) || tasks.find(t => !t.is_completed);
      if (focus) setSelectedTaskId(focus.id);
    }
  }, [tasks]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      playBell();
      if (mode === 'focus') {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        setMode('focus');
        setTimeLeft(25 * 60);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, mode]);

  if (!isOpen) return null;

  const handleModeChange = (newMode: 'focus' | 'break', mins: number) => {
    setMode(newMode);
    setDuration(mins * 60);
    setTimeLeft(mins * 60);
    setIsRunning(false);
  };

  const handleCompleteCurrentTask = async () => {
    if (selectedTaskId && onTaskCompleted) {
      playComplete();
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      await onTaskCompleted(selectedTaskId);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = ((duration - timeLeft) / duration) * 100;
  const selectedTask = tasks.find(t => t.id === selectedTaskId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-zinc-800 p-6 sm:p-8 text-center">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 dark:hover:text-white rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-center gap-2 mb-4">
          <button
            onClick={() => handleModeChange('focus', 25)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
              mode === 'focus'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/30'
                : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
            }`}
          >
            🔥 Глубокий фокус (25м)
          </button>
          <button
            onClick={() => handleModeChange('break', 5)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
              mode === 'break'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30'
                : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
            }`}
          >
            ☕ Перерыв (5м)
          </button>
        </div>

        {/* Selected Task Hero */}
        {selectedTask && (
          <div className="mb-4 p-3 rounded-2xl bg-stone-50 dark:bg-zinc-800/80 border border-stone-200/80 dark:border-zinc-700/60 text-left">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 block mb-0.5">
              В работе сейчас:
            </span>
            <p className="text-xs sm:text-sm font-semibold text-stone-900 dark:text-white truncate">
              {selectedTask.title}
            </p>
          </div>
        )}

        {/* Circular Progress Display */}
        <div className="relative w-52 h-52 mx-auto my-6 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
            <circle
              className="text-stone-100 dark:text-zinc-800"
              strokeWidth="6"
              stroke="currentColor"
              fill="transparent"
              r="42"
              cx="50"
              cy="50"
            />
            <circle
              className={mode === 'focus' ? 'text-amber-500 transition-all duration-1000' : 'text-emerald-500 transition-all duration-1000'}
              strokeWidth="6"
              strokeDasharray={264}
              strokeDashoffset={264 - (264 * progress) / 100}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
              r="42"
              cx="50"
              cy="50"
            />
          </svg>

          <div className="absolute flex flex-col items-center">
            <span className="text-4xl sm:text-5xl font-black text-stone-900 dark:text-white font-mono tracking-tight">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <span className="text-xs font-semibold text-stone-400 uppercase tracking-widest mt-1">
              {mode === 'focus' ? 'Фокус в потоке' : 'Перезагрузка'}
            </span>
          </div>
        </div>

        {/* Timer Controls */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <button
            onClick={() => setTimeLeft(duration)}
            className="p-3 rounded-2xl bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-300 hover:bg-stone-200 transition"
            title="Сброс"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-8 py-3.5 rounded-2xl text-white font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg transition active:scale-95 ${
              isRunning
                ? 'bg-rose-500 hover:bg-rose-600 shadow-rose-500/30'
                : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-amber-500/30'
            }`}
          >
            {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
            <span>{isRunning ? 'Пауза' : 'Старт потока'}</span>
          </button>
        </div>

        {/* Ambient Sound Selector */}
        <div className="pt-4 border-t border-stone-100 dark:border-zinc-800">
          <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block mb-2">
            Фоновый шум для концентрации:
          </span>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { id: 'off' as AmbientSound, label: 'Тишина', icon: '🔇' },
              { id: 'rain' as AmbientSound, label: 'Дождь', icon: '🌧️' },
              { id: 'whitenoise' as AmbientSound, label: 'Белый шум', icon: '📻' },
              { id: 'zen' as AmbientSound, label: 'Дзен', icon: '🧘' }
            ].map((amb) => (
              <button
                key={amb.id}
                onClick={() => setAmbientSound(amb.id)}
                className={`py-1.5 px-2 rounded-xl text-xs font-medium transition flex flex-col items-center gap-0.5 ${
                  ambientSound === amb.id
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 font-bold border border-amber-300 dark:border-amber-700'
                    : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400 hover:bg-stone-200'
                }`}
              >
                <span>{amb.icon}</span>
                <span className="text-[10px] truncate">{amb.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Complete Task Button */}
        {selectedTask && (
          <div className="mt-4">
            <button
              onClick={handleCompleteCurrentTask}
              className="w-full py-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-300 dark:border-emerald-800 flex items-center justify-center gap-1.5 transition"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Завершить задачу «{selectedTask.title.slice(0, 20)}...»</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
