import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id = 'demo-user', limit = 30 } = req.query;
      const { data, error } = await supabase
        .from('energy_logs')
        .select('*')
        .eq('user_id', user_id)
        .order('date', { ascending: false })
        .limit(Number(limit));

      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const {
        user_id = 'demo-user',
        date = new Date().toISOString().split('T')[0],
        energy_level = 4,
        mood = 'Вдохновение',
        note = '',
        focus_state = 'Глубокий фокус'
      } = req.body;

      // Upsert by date & user_id if already exists for today or insert
      const { data: existing } = await supabase
        .from('energy_logs')
        .select('id')
        .eq('user_id', user_id)
        .eq('date', date)
        .limit(1);

      let data, error;
      if (existing && existing.length > 0) {
        const resUp = await supabase
          .from('energy_logs')
          .update({
            energy_level: Number(energy_level),
            mood,
            note,
            focus_state
          })
          .eq('id', existing[0].id)
          .select()
          .single();
        data = resUp.data;
        error = resUp.error;
      } else {
        const resIn = await supabase
          .from('energy_logs')
          .insert({
            user_id,
            date,
            energy_level: Number(energy_level),
            mood,
            note,
            focus_state
          })
          .select()
          .single();
        data = resIn.data;
        error = resIn.error;
      }

      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /api/energy error:', err);
    res.status(500).json({ error: err.message });
  }
}
