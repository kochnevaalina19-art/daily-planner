// Smart task decomposition engine to relieve mental overload for busy women and men
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { taskTitle, context = '' } = req.body;
    if (!taskTitle) {
      return res.status(400).json({ error: 'Task title is required' });
    }

    const titleLower = taskTitle.toLowerCase();
    let steps = [];
    let advice = '';
    let estimatedTotalMinutes = 60;

    // Intelligent heuristic breakdown based on common modern scenarios
    if (titleLower.includes('отчет') || titleLower.includes('презентац') || titleLower.includes('слайд')) {
      steps = [
        { title: 'Собрать ключевые цифры и факты в один черновик (10 мин)', estimated_minutes: 10 },
        { title: 'Набросать структуру из 4-5 главных разделов (15 мин)', estimated_minutes: 15 },
        { title: 'Написать основной текст/заполнить слайды без перфекционизма (25 мин)', estimated_minutes: 25 },
        { title: 'Финальная вычитка, визуальное оформление и проверка ссылок (15 мин)', estimated_minutes: 15 },
        { title: 'Отправить ссылку или файл адресату и поставить галочку (5 мин)', estimated_minutes: 5 }
      ];
      advice = '💡 Правило 80/20: сделай сначала черновую версию за 25 минут, идеализировать будешь в конце.';
      estimatedTotalMinutes = 70;
    } else if (titleLower.includes('тренировк') || titleLower.includes('спорт') || titleLower.includes('зарядк') || titleLower.includes('здоров')) {
      steps = [
        { title: 'Приготовить форму и бутылку с водой (3 мин)', estimated_minutes: 3 },
        { title: 'Мягкая суставная разминка и дыхание (7 мин)', estimated_minutes: 7 },
        { title: 'Основной блок упражнений в комфортном пульсе (25 мин)', estimated_minutes: 25 },
        { title: 'Заминка, растяжка и стакан чистой воды (10 мин)', estimated_minutes: 10 }
      ];
      advice = '⚡ Лучше сделать 20 минут регулярно, чем 2 часа раз в месяц. Тело скажет спасибо!';
      estimatedTotalMinutes = 45;
    } else if (titleLower.includes('уборк') || titleLower.includes('порядок') || titleLower.includes('вещи') || titleLower.includes('гардероб')) {
      steps = [
        { title: 'Включить любимый плейлист или подкаст для настроения (2 мин)', estimated_minutes: 2 },
        { title: 'Собрать весь видимый мусор и лишние предметы в одну корзину (10 мин)', estimated_minutes: 10 },
        { title: 'Расставить вещи по своим законным местам (15 мин)', estimated_minutes: 15 },
        { title: 'Протереть поверхности и проветрить комнату свежим воздухом (10 мин)', estimated_minutes: 10 }
      ];
      advice = '🌿 Раздели пространство на зоны: начни только с рабочего стола или одной полки.';
      estimatedTotalMinutes = 37;
    } else if (titleLower.includes('звонок') || titleLower.includes('встреч') || titleLower.includes('переговор') || titleLower.includes('клиент')) {
      steps = [
        { title: 'Выписать 3 главные цели и тезисы перед звонком (5 мин)', estimated_minutes: 5 },
        { title: 'Подготовить необходимые ссылки, файлы и вопросы (5 мин)', estimated_minutes: 5 },
        { title: 'Провести разговор с фокусом на результат (20 мин)', estimated_minutes: 20 },
        { title: 'Зафиксировать договоренности и следующие шаги в заметку (5 мин)', estimated_minutes: 5 }
      ];
      advice = '🎯 Четкие 3 тезиса на бумаге снимают 90% тревожности перед важным звонком.';
      estimatedTotalMinutes = 35;
    } else if (titleLower.includes('курс') || titleLower.includes('учеб') || titleLower.includes('книг') || titleLower.includes('англ')) {
      steps = [
        { title: 'Убрать телефон в другую комнату и налить чай (3 мин)', estimated_minutes: 3 },
        { title: 'Изучить 1 урок или прочитать 15 страниц без отвлечений (25 мин)', estimated_minutes: 25 },
        { title: 'Выписать 2 главных инсайта в свои заметки (7 мин)', estimated_minutes: 7 },
        { title: 'Придумать, как применить один инсайт уже сегодня (5 мин)', estimated_minutes: 5 }
      ];
      advice = '📚 Один внедренный инсайт ценнее 10 прочитанных глав без практики.';
      estimatedTotalMinutes = 40;
    } else {
      // General decomposition
      steps = [
        { title: `Быстро сформулировать ожидаемый результат для "${taskTitle}" (5 мин)`, estimated_minutes: 5 },
        { title: 'Собрать все исходные материалы и закрыть лишние вкладки (10 мин)', estimated_minutes: 10 },
        { title: 'Сделать первый самый легкий шаг (15 мин)', estimated_minutes: 15 },
        { title: 'Сделать основной объем работы в режиме глубокого фокуса (25 мин)', estimated_minutes: 25 },
        { title: 'Проверить результат и отпраздновать завершение (5 мин)', estimated_minutes: 5 }
      ];
      advice = '🚀 Самое сложное — сесть и начать первые 2 минуты. Дальше включится инерция потока!';
      estimatedTotalMinutes = 60;
    }

    return res.status(200).json({
      taskTitle,
      steps,
      advice,
      estimatedTotalMinutes
    });
  } catch (err) {
    console.error('API /api/ai-breakdown error:', err);
    res.status(500).json({ error: err.message });
  }
}
