import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, status, is_focus, horizon, goal_id, search } = req.query;
      let query = supabase.from('tasks').select('*').order('created_at', { ascending: false });

      if (user_id) query = query.eq('user_id', user_id);
      if (status) query = query.eq('status', status);
      if (is_focus !== undefined) query = query.eq('is_focus', is_focus === 'true');
      if (horizon) query = query.eq('horizon', horizon);
      if (goal_id) query = query.eq('goal_id', goal_id);
      if (search) query = query.ilike('title', `%${search}%`);

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const {
        user_id = 'demo-user',
        title,
        description = '',
        is_focus = false,
        is_completed = false,
        status = 'inbox',
        priority = 'medium',
        horizon = 'day',
        goal_id = null,
        due_date = null,
        estimated_minutes = 30,
        actual_minutes = 0,
        subtasks = []
      } = req.body;

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Title is required' });
      }

      const { data, error } = await supabase
        .from('tasks')
        .insert({
          user_id,
          title: title.trim(),
          description: description || '',
          is_focus: Boolean(is_focus),
          is_completed: Boolean(is_completed),
          status: status || (is_focus ? 'today' : 'inbox'),
          priority: priority || 'medium',
          horizon: horizon || 'day',
          goal_id: goal_id || null,
          due_date: due_date || null,
          estimated_minutes: Number(estimated_minutes) || 30,
          actual_minutes: Number(actual_minutes) || 0,
          subtasks: Array.isArray(subtasks) ? subtasks : []
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'Task ID is required' });

      // Automatically sync is_completed and status
      if (updates.is_completed !== undefined && updates.status === undefined) {
        updates.status = updates.is_completed ? 'completed' : (updates.is_focus ? 'today' : 'inbox');
      }

      const { data, error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'Task ID is required' });

      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /api/tasks error:', err);
    res.status(500).json({ error: err.message });
  }
}
