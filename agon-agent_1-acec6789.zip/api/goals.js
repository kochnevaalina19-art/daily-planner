import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, horizon, category } = req.query;
      let query = supabase.from('goals').select('*').order('created_at', { ascending: true });

      if (user_id) query = query.eq('user_id', user_id);
      if (horizon) query = query.eq('horizon', horizon);
      if (category) query = query.eq('category', category);

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const {
        user_id = 'demo-user',
        title,
        description = '',
        horizon = 'month',
        category = 'Карьера & Проекты',
        target_date = null,
        progress = 0,
        status = 'in_progress',
        key_results = [],
        color = 'emerald'
      } = req.body;

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Goal title is required' });
      }

      const { data, error } = await supabase
        .from('goals')
        .insert({
          user_id,
          title: title.trim(),
          description: description || '',
          horizon: horizon || 'month',
          category: category || 'Карьера & Проекты',
          target_date: target_date || null,
          progress: Number(progress) || 0,
          status: status || 'in_progress',
          key_results: Array.isArray(key_results) ? key_results : [],
          color: color || 'emerald'
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'Goal ID is required' });

      const { data, error } = await supabase
        .from('goals')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'Goal ID is required' });

      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /api/goals error:', err);
    res.status(500).json({ error: err.message });
  }
}
