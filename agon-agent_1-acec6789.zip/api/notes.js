import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, tag, search } = req.query;
      let query = supabase.from('notes').select('*').order('is_pinned', { ascending: false }).order('created_at', { ascending: false });

      if (user_id) query = query.eq('user_id', user_id);
      if (search) query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`);

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const {
        user_id = 'demo-user',
        title,
        content = '',
        tags = [],
        is_pinned = false,
        color = 'amber',
        checklist = []
      } = req.body;

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Note title is required' });
      }

      const { data, error } = await supabase
        .from('notes')
        .insert({
          user_id,
          title: title.trim(),
          content: content || '',
          tags: Array.isArray(tags) ? tags : [],
          is_pinned: Boolean(is_pinned),
          color: color || 'amber',
          checklist: Array.isArray(checklist) ? checklist : []
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'Note ID is required' });

      const { data, error } = await supabase
        .from('notes')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'Note ID is required' });

      const { error } = await supabase
        .from('notes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /api/notes error:', err);
    res.status(500).json({ error: err.message });
  }
}
